#define BLYNK_TEMPLATE_ID   "TMPL34zp_uSS-"      // <-- replace with your Template ID
#define BLYNK_TEMPLATE_NAME "BMS Dashboard"    // <-- replace with your Template Name
#define BLYNK_AUTH_TOKEN    "cdJvP-_V3i77M6IOnl-fdO83ZyIyifUyv" // <-- device auth token
#define BLYNK_PRINT Serial

#include <WiFi.h>
#include <BlynkSimpleEsp32.h>

/* --------------------------- Wokwi network -------------------------------
 * Wokwi's virtual ESP32 bridges "Wokwi-GUEST" to real internet, so the
 * simulated device can reach Blynk Cloud exactly like real hardware.
 * --------------------------------------------------------------------------*/
char ssid[] = "Wokwi-GUEST";
char pass[] = "";

/* ----------------------------- Pin map ------------------------------------
 * See README.md "Connection List" for the full Wokwi wiring table.
 * ADC1-only pins are used for all analog inputs (32,33,34,35,36,39) so
 * readings stay valid while WiFi (which owns ADC2) is active.
 * --------------------------------------------------------------------------*/
#define PIN_CELL1   34
#define PIN_CELL2   35
#define PIN_CELL3   32
#define PIN_CELL4   33
#define PIN_TEMP    36
#define PIN_CURRENT 39
#define PIN_BTN_FAULT 13   // manual fault-injection push button (INPUT_PULLUP)
#define LED_GREEN   25
#define LED_YELLOW  26
#define LED_RED     27

/* --------------------------- Virtual pins ---------------------------------
 * V0  SoC (%)                 - Gauge, logged to SuperChart
 * V1  Pack Voltage (V)        - Value Display, logged to SuperChart
 * V2  Cell Imbalance (mV)     - Value Display, logged to SuperChart
 * V3  Temperature (C)         - Value Display, logged to SuperChart
 * V4  Pack Current (A)        - Value Display, logged to SuperChart
 * V5  Risk Score (0-100)      - Gauge, logged to SuperChart
 * V6  State Name              - Label, color set live via setProperty
 * V7  Uptime (HH:MM:SS)       - Label
 * V8  Total Fault Count       - Value Display
 * V9  Fault / recommendation  - Terminal widget
 * V10 Executive Summary       - Label (multi-line)
 * V11 Manual Fault Inject     - Button (app -> device)
 * V12 Reset Demo              - Button (app -> device)
 * --------------------------------------------------------------------------*/

BlynkTimer timer;
WidgetTerminal terminal(V9);

/* ------------------------------ State machine ------------------------------ */
enum BmsState { IDLE, CHARGING, DISCHARGING, WARNING, FAULT, CRITICAL };
BmsState currentState = IDLE;
BmsState previousState = IDLE;

const char* STATE_NAME[]  = { "IDLE", "CHARGING", "DISCHARGING", "WARNING", "FAULT", "CRITICAL" };
const char* STATE_COLOR[] = { "#9E9E9E", "#2196F3", "#4CAF50", "#FF9800", "#F44336", "#B71C1C" };

/* ------------------------------ Live metrics -------------------------------- */
float cellV[4]      = {0,0,0,0};
float packVoltage    = 0;
float imbalance_mV   = 0;
float temperature_C  = 0;
float current_A      = 0;
float soc_pct        = 0;
float riskScore      = 0;
bool  manualFault     = false;

/* ------------------------------ Fault history -------------------------------
 * Circular buffer of the last MAX_FAULTS events for structured fault history.
 * --------------------------------------------------------------------------*/
struct FaultRecord {
  unsigned long timestamp;   // millis() at time of fault
  String        code;        // e.g. "F-IMB", "F-TEMP", "F-MANUAL"
  String        message;     // human readable
  uint8_t       severity;    // 1=WARNING 2=FAULT 3=CRITICAL
};
#define MAX_FAULTS 8
FaultRecord faultLog[MAX_FAULTS];
uint8_t faultHead = 0;
uint32_t totalFaultCount = 0;

/* Rolling fault-frequency window for the risk engine (faults / 10 min) */
#define FREQ_WINDOW_MS (10UL * 60UL * 1000UL)
unsigned long faultTimestamps[32];
uint8_t faultTsHead = 0;
uint8_t faultTsCount = 0;

unsigned long demoStartMillis = 0;

/* ============================================================================
 *  SENSOR ACQUISITION  (simulated via potentiometers in Wokwi)
 * ==========================================================================*/
void readSensors() {
  // Each pot models one series cell, scaled 0-4.2V from the 0-3.3V ADC range.
  cellV[0] = (analogRead(PIN_CELL1) / 4095.0) * 4.2;
  cellV[1] = (analogRead(PIN_CELL2) / 4095.0) * 4.2;
  cellV[2] = (analogRead(PIN_CELL3) / 4095.0) * 4.2;
  cellV[3] = (analogRead(PIN_CELL4) / 4095.0) * 4.2;

  packVoltage = cellV[0] + cellV[1] + cellV[2] + cellV[3];

  float vmax = cellV[0], vmin = cellV[0];
  for (uint8_t i = 1; i < 4; i++) {
    if (cellV[i] > vmax) vmax = cellV[i];
    if (cellV[i] < vmin) vmin = cellV[i];
  }
  imbalance_mV = (vmax - vmin) * 1000.0;

  // Temperature pot models 0-80C
  temperature_C = (analogRead(PIN_TEMP) / 4095.0) * 80.0;

  // Current pot models -10A (charge) .. +20A (discharge)
  float raw = analogRead(PIN_CURRENT) / 4095.0;
  current_A = -10.0 + raw * 30.0;

  // SoC estimated from pack voltage window 12.0V (0%) - 16.8V (100%)
  soc_pct = (packVoltage - 12.0) / (16.8 - 12.0) * 100.0;
  soc_pct = constrain(soc_pct, 0, 100);

  manualFault = (digitalRead(PIN_BTN_FAULT) == LOW);
}

/* ============================================================================
 *  RISK ENGINE — composite 0-100 score
 *  risk = 0.30*imbalanceRisk + 0.25*socRisk + 0.25*faultFreqRisk + 0.20*tempRisk
 * ==========================================================================*/
uint8_t recentFaultCount() {
  unsigned long now = millis();
  uint8_t count = 0;
  for (uint8_t i = 0; i < faultTsCount; i++) {
    if (now - faultTimestamps[i] <= FREQ_WINDOW_MS) count++;
  }
  return count;
}

float computeRiskScore() {
  float imbalanceRisk = constrain(map(imbalance_mV, 0, 300, 0, 100), 0, 100);
  float socRisk        = constrain(100.0 - soc_pct, 0, 100);
  float faultFreqRisk  = constrain(recentFaultCount() * 15.0, 0, 100);
  float tempRisk        = constrain(map(temperature_C, 25, 65, 0, 100), 0, 100);

  return 0.30 * imbalanceRisk + 0.25 * socRisk + 0.25 * faultFreqRisk + 0.20 * tempRisk;
}

/* ============================================================================
 *  FAULT LOGGING
 * ==========================================================================*/
void logFault(const String &code, const String &message, uint8_t severity) {
  faultLog[faultHead] = { millis(), code, message, severity };
  faultHead = (faultHead + 1) % MAX_FAULTS;
  totalFaultCount++;

  faultTimestamps[faultTsHead] = millis();
  faultTsHead = (faultTsHead + 1) % 32;
  if (faultTsCount < 32) faultTsCount++;

  String line = "[" + formatUptime(millis()) + "] " + code + " (sev " + String(severity) + "): " + message;
  terminal.println(line);
  terminal.flush();
  Serial.println(line);
}

/* ============================================================================
 *  STATE MACHINE  — mirrors Task-4 definitions; hysteresis avoids chatter
 * ==========================================================================*/
BmsState evaluateState() {
  // Highest severity wins.
  if (temperature_C > 60 || manualFault) {
    if (previousState != CRITICAL)
      logFault(manualFault ? "F-MANUAL" : "F-TEMP",
                manualFault ? "Manual fault trigger asserted" : "Over-temperature threshold exceeded",
                3);
    return CRITICAL;
  }
  if (imbalance_mV > 300) {
    if (previousState != FAULT && previousState != CRITICAL)
      logFault("F-IMB", "Cell imbalance exceeded 300 mV", 2);
    return FAULT;
  }
  if (imbalance_mV > 150 || temperature_C > 45 || soc_pct < 15) {
    if (previousState != WARNING && previousState != FAULT && previousState != CRITICAL)
      logFault("W-THRESH", "One or more metrics entered warning band", 1);
    return WARNING;
  }
  if (current_A < -0.5) return CHARGING;
  if (current_A >  0.5) return DISCHARGING;
  return IDLE;
}

/* ============================================================================
 *  RECOMMENDATION ENGINE — human-readable operator guidance
 * ==========================================================================*/
String generateRecommendation() {
  if (currentState == CRITICAL)
    return manualFault
      ? "CRITICAL: Manual fault asserted. Isolate pack and inspect before restart."
      : "CRITICAL: Over-temperature. Stop charge/discharge, allow pack to cool, inspect thermal path.";
  if (currentState == FAULT)
    return "FAULT: Cell imbalance " + String(imbalance_mV, 0) + " mV exceeds safe limit. Schedule active balancing before next cycle.";
  if (currentState == WARNING) {
    if (soc_pct < 15) return "WARNING: SoC low (" + String(soc_pct, 1) + "%). Recommend charging soon to avoid deep discharge.";
    if (temperature_C > 45) return "WARNING: Elevated pack temperature (" + String(temperature_C, 1) + " C). Reduce load or improve cooling.";
    return "WARNING: Cell imbalance rising (" + String(imbalance_mV, 0) + " mV). Monitor closely; balance at next opportunity.";
  }
  if (riskScore > 60) return "Risk trending high (" + String(riskScore, 0) + "/100) despite nominal state. Investigate root cause proactively.";
  return "Pack operating within normal parameters. No action required.";
}

/* ============================================================================
 *  FORMATTING HELPERS
 * ==========================================================================*/
String formatUptime(unsigned long ms) {
  unsigned long totalSec = ms / 1000;
  unsigned int h = totalSec / 3600;
  unsigned int m = (totalSec % 3600) / 60;
  unsigned int s = totalSec % 60;
  char buf[16];
  snprintf(buf, sizeof(buf), "%02u:%02u:%02u", h, m, s);
  return String(buf);
}

/* ============================================================================
 *  LOCAL INDICATORS (mirrors the app-side severity colors on real hardware)
 * ==========================================================================*/
void updateLocalLEDs() {
  digitalWrite(LED_GREEN,  (currentState == IDLE || currentState == CHARGING || currentState == DISCHARGING));
  digitalWrite(LED_YELLOW, (currentState == WARNING));
  digitalWrite(LED_RED,    (currentState == FAULT || currentState == CRITICAL));
}

/* ============================================================================
 *  MAIN DASHBOARD UPDATE — runs every 2s via BlynkTimer
 * ==========================================================================*/
void updateDashboard() {
  readSensors();

  previousState = currentState;
  currentState = evaluateState();
  riskScore = computeRiskScore();
  updateLocalLEDs();

  // --- Time-series datastreams (SuperChart pulls history automatically) ---
  Blynk.virtualWrite(V0, soc_pct);
  Blynk.virtualWrite(V1, packVoltage);
  Blynk.virtualWrite(V2, imbalance_mV);
  Blynk.virtualWrite(V3, temperature_C);
  Blynk.virtualWrite(V4, current_A);
  Blynk.virtualWrite(V5, riskScore);

  // --- State + severity color, synced to Task-4 state machine ---
  Blynk.virtualWrite(V6, STATE_NAME[currentState]);
  Blynk.setProperty(V6, "color", STATE_COLOR[currentState]);

  // --- Executive summary block ---
  Blynk.virtualWrite(V7, formatUptime(millis() - demoStartMillis));
  Blynk.virtualWrite(V8, totalFaultCount);

  String health = (riskScore < 25) ? "GOOD" : (riskScore < 50) ? "FAIR" : (riskScore < 75) ? "DEGRADED" : "POOR";
  String summary = "Health: " + health +
                    " | State: " + String(STATE_NAME[currentState]) +
                    " | SoC: " + String(soc_pct, 0) + "%" +
                    " | Risk: " + String(riskScore, 0) + "/100" +
                    " | Faults: " + String(totalFaultCount) +
                    " | Uptime: " + formatUptime(millis() - demoStartMillis);
  Blynk.virtualWrite(V10, summary);

  // --- Recommendation, pushed to terminal only when state changes to avoid
  //     flooding the log; risk score still updates every cycle above. ---
  if (currentState != previousState) {
    terminal.println("--- STATE TRANSITION: " + String(STATE_NAME[previousState]) +
                      " -> " + String(STATE_NAME[currentState]) + " ---");
    terminal.println(generateRecommendation());
    terminal.flush();

    // Push a mobile notification on serious transitions
    if (currentState == FAULT || currentState == CRITICAL) {
      Blynk.logEvent("bms_alert", generateRecommendation());
    }
  }
}

/* ============================================================================
 *  APP -> DEVICE HANDLERS
 * ==========================================================================*/
BLYNK_WRITE(V11) {  // manual fault-injection button in the app
  int pressed = param.asInt();
  if (pressed) logFault("F-MANUAL-APP", "Fault injected from Blynk app", 3);
}

BLYNK_WRITE(V12) {  // demo reset button
  int pressed = param.asInt();
  if (pressed) {
    totalFaultCount = 0;
    faultTsCount = 0;
    faultTsHead = 0;
    demoStartMillis = millis();
    terminal.clear();
    terminal.println("=== Demo reset ===");
    terminal.flush();
  }
}

BLYNK_CONNECTED() {
  Blynk.syncVirtual(V11, V12);
}

/* ============================================================================
 *  SETUP / LOOP
 * ==========================================================================*/
void setup() {
  Serial.begin(115200);

  pinMode(PIN_BTN_FAULT, INPUT_PULLUP);
  pinMode(LED_GREEN, OUTPUT);
  pinMode(LED_YELLOW, OUTPUT);
  pinMode(LED_RED, OUTPUT);

  Blynk.begin(BLYNK_AUTH_TOKEN, ssid, pass);

  demoStartMillis = millis();
  terminal.clear();
  terminal.println("=== BMS Analytics Dashboard online ===");
  terminal.flush();

  timer.setInterval(2000L, updateDashboard);
}

void loop() {
  Blynk.run();
  timer.run();
}
