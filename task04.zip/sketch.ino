#include "FaultManager.h"

// =================================================
// PIN DEFINITIONS
// =================================================

#define CELL1_ADC       34
#define CELL2_ADC       35

#define RELAY_CONTROL   26
#define RELAY_FEEDBACK  27

#define COMM_FAULT_PIN  25
#define FAULT_TEST_PIN  33

#define STATUS_LED      2


// =================================================
// TIMING
// =================================================

const unsigned long ADC_FREEZE_TIME =
  5000;

const unsigned long RELAY_SETTLE_TIME =
  500;

const unsigned long DEGRADED_TIMEOUT =
  5000;

const unsigned long FAILSAFE_VERIFY_TIME =
  3000;

const unsigned long FAILSAFE_TIMEOUT =
  30000;


// =================================================
// ADC VARIABLES
// =================================================

int previousADC1 = -1;
int previousADC2 = -1;

unsigned long adc1FrozenSince = 0;
unsigned long adc2FrozenSince = 0;

const int ADC_CHANGE_THRESHOLD = 2;


// =================================================
// RELAY VARIABLES
// =================================================

bool relayCommand = false;

unsigned long relayCommandTime = 0;


// =================================================
// FAILSAFE VARIABLES
// =================================================

bool verificationStarted = false;

unsigned long failsafeVerificationStart = 0;


// =================================================
// RELAY CONTROL
// =================================================

void setRelay(bool state) {

  // Do not repeatedly reset timer
  if (relayCommand == state) {
    return;
  }

  relayCommand = state;

  digitalWrite(
    RELAY_CONTROL,
    state ? HIGH : LOW
  );

  relayCommandTime =
    millis();

  Serial.print("[RELAY COMMAND] ");

  Serial.println(
    state ? "ON" : "OFF"
  );
}


// =================================================
// RELAY FEEDBACK CHECK
// =================================================

bool checkRelay() {

  // Allow relay to settle
  if (millis() -
      relayCommandTime <
      RELAY_SETTLE_TIME) {

    return true;
  }

  bool feedback =
    digitalRead(RELAY_FEEDBACK);

  if (feedback != relayCommand) {

    setFault(
      FAULT_RELAY_MISMATCH,
      SOURCE_RELAY
    );

    return false;
  }

  return true;
}


// =================================================
// ADC CHECK
// =================================================

bool checkADC() {

  int adc1 =
    analogRead(CELL1_ADC);

  int adc2 =
    analogRead(CELL2_ADC);


  Serial.print("ADC1=");
  Serial.print(adc1);

  Serial.print(" ADC2=");
  Serial.println(adc2);


  // -----------------------------------------------
  // CELL 1 FREEZE
  // -----------------------------------------------

  if (previousADC1 >= 0) {

    if (abs(adc1 - previousADC1)
        <= ADC_CHANGE_THRESHOLD) {

      if (adc1FrozenSince == 0) {

        adc1FrozenSince =
          millis();
      }

      if (millis() -
          adc1FrozenSince >=
          ADC_FREEZE_TIME) {

        setFault(
          FAULT_ADC_FROZEN,
          SOURCE_ADC
        );

        return false;
      }

    } else {

      adc1FrozenSince = 0;
    }
  }


  // -----------------------------------------------
  // CELL 2 FREEZE
  // -----------------------------------------------

  if (previousADC2 >= 0) {

    if (abs(adc2 - previousADC2)
        <= ADC_CHANGE_THRESHOLD) {

      if (adc2FrozenSince == 0) {

        adc2FrozenSince =
          millis();
      }

      if (millis() -
          adc2FrozenSince >=
          ADC_FREEZE_TIME) {

        setFault(
          FAULT_ADC_FROZEN,
          SOURCE_ADC
        );

        return false;
      }

    } else {

      adc2FrozenSince = 0;
    }
  }


  previousADC1 = adc1;
  previousADC2 = adc2;

  return true;
}


// =================================================
// BATTERY CHECK
// =================================================

bool checkBattery() {

  int cell1 =
    analogRead(CELL1_ADC);

  int cell2 =
    analogRead(CELL2_ADC);


  if (cell1 < 100) {

    setFault(
      FAULT_CELL1_ADC,
      SOURCE_BATTERY_CELL1
    );

    return false;
  }


  if (cell2 < 100) {

    setFault(
      FAULT_CELL2_ADC,
      SOURCE_BATTERY_CELL2
    );

    return false;
  }


  return true;
}


// =================================================
// COMMUNICATION CHECK
// =================================================

bool checkCommunication() {

  // INPUT_PULLUP:
  // HIGH = normal
  // LOW  = fault

  if (digitalRead(COMM_FAULT_PIN)
      == LOW) {

    setFault(
      FAULT_COMMUNICATION,
      SOURCE_COMMUNICATION
    );

    return false;
  }

  return true;
}


// =================================================
// NORMAL STATE
// =================================================

void handleNormal() {

  bool adcOK =
    checkADC();

  bool relayOK =
    checkRelay();

  bool batteryOK =
    checkBattery();

  bool communicationOK =
    checkCommunication();


  // Relay fault → immediate FAILSAFE

  if (!relayOK) {

    changeState(
      FAILSAFE,
      activeFault.id
    );

    return;
  }


  // Other faults → DEGRADED

  if (!adcOK ||
      !batteryOK ||
      !communicationOK) {

    changeState(
      DEGRADED,
      activeFault.id
    );

    return;
  }
}


// =================================================
// DEGRADED STATE
// =================================================

void handleDegraded() {

  Serial.println(
    "[STATE] DEGRADED"
  );


  bool adcOK =
    checkADC();

  bool relayOK =
    checkRelay();

  bool batteryOK =
    checkBattery();

  bool communicationOK =
    checkCommunication();


  // Relay mismatch → FAILSAFE

  if (!relayOK) {

    changeState(
      FAILSAFE,
      activeFault.id
    );

    return;
  }


  // Persistent fault

  if (!adcOK ||
      !batteryOK ||
      !communicationOK) {

    if (millis() -
        stateEntryTime >=
        DEGRADED_TIMEOUT) {

      changeState(
        FAILSAFE,
        activeFault.id
      );

      return;
    }

    return;
  }


  // Everything healthy

  clearFault();

  changeState(
    NORMAL,
    FAULT_NONE
  );
}


// =================================================
// FAILSAFE VERIFICATION
// =================================================

bool verifySystem() {

  Serial.println(
    "[VERIFICATION] Checking..."
  );


  // -----------------------------------------------
  // RELAY MUST BE OFF
  // -----------------------------------------------

  bool relayFeedback =
    digitalRead(RELAY_FEEDBACK);


  if (relayFeedback != LOW) {

    setFault(
      FAULT_RELAY_MISMATCH,
      SOURCE_RELAY
    );

    Serial.println(
      "[VERIFY FAIL] Relay"
    );

    return false;
  }


  // -----------------------------------------------
  // BATTERY / ADC
  // -----------------------------------------------

  int adc1 =
    analogRead(CELL1_ADC);

  int adc2 =
    analogRead(CELL2_ADC);


  if (adc1 < 100) {

    setFault(
      FAULT_CELL1_ADC,
      SOURCE_BATTERY_CELL1
    );

    Serial.println(
      "[VERIFY FAIL] Cell 1"
    );

    return false;
  }


  if (adc2 < 100) {

    setFault(
      FAULT_CELL2_ADC,
      SOURCE_BATTERY_CELL2
    );

    Serial.println(
      "[VERIFY FAIL] Cell 2"
    );

    return false;
  }


  // -----------------------------------------------
  // COMMUNICATION
  // -----------------------------------------------

  if (digitalRead(COMM_FAULT_PIN)
      == LOW) {

    setFault(
      FAULT_COMMUNICATION,
      SOURCE_COMMUNICATION
    );

    Serial.println(
      "[VERIFY FAIL] Communication"
    );

    return false;
  }


  Serial.println(
    "[VERIFY PASS]"
  );

  return true;
}


// =================================================
// FAILSAFE STATE
// =================================================

void handleFailsafe() {

  Serial.println(
    "[STATE] FAILSAFE"
  );


  // -----------------------------------------------
  // TURN RELAY OFF
  // -----------------------------------------------

  setRelay(false);


  // -----------------------------------------------
  // START VERIFICATION
  // -----------------------------------------------

  if (!verificationStarted) {

    verificationStarted =
      true;

    failsafeVerificationStart =
      millis();

    Serial.println(
      "[FAILSAFE] Verification started"
    );

    return;
  }


  // -----------------------------------------------
  // VERIFY AFTER 3 SECONDS
  // -----------------------------------------------

  if (millis() -
      failsafeVerificationStart >=
      FAILSAFE_VERIFY_TIME) {

    if (verifySystem()) {

      clearFault();

      verificationStarted =
        false;

      changeState(
        NORMAL,
        FAULT_NONE
      );

      return;
    }


    // Verification failed
    // Start another verification cycle

    failsafeVerificationStart =
      millis();
  }


  // -----------------------------------------------
  // RECOVERY TIMEOUT
  // -----------------------------------------------

  if (millis() -
      stateEntryTime >=
      FAILSAFE_TIMEOUT) {

    Serial.println(
      "[FAILSAFE] Recovery timeout"
    );

    verificationStarted =
      false;

    changeState(
      SHUTDOWN,
      activeFault.id
    );
  }
}


// =================================================
// SHUTDOWN STATE
// =================================================

void handleShutdown() {

  Serial.println(
    "[STATE] SHUTDOWN"
  );


  // Keep relay OFF

  setRelay(false);

  digitalWrite(
    STATUS_LED,
    LOW
  );
}


// =================================================
// SETUP
// =================================================

void setup() {

  Serial.begin(115200);

  delay(1000);


  Serial.println();
  Serial.println(
    "================================"
  );

  Serial.println(
    "FAULT STATE MACHINE"
  );

  Serial.println(
    "================================"
  );


  // -----------------------------------------------
  // DIGITAL PINS
  // -----------------------------------------------

  pinMode(
    RELAY_CONTROL,
    OUTPUT
  );

  pinMode(
    RELAY_FEEDBACK,
    INPUT_PULLDOWN
  );

  pinMode(
    COMM_FAULT_PIN,
    INPUT_PULLUP
  );

  pinMode(
    FAULT_TEST_PIN,
    INPUT_PULLUP
  );

  pinMode(
    STATUS_LED,
    OUTPUT
  );


  // -----------------------------------------------
  // ADC PINS
  // -----------------------------------------------

  pinMode(
    CELL1_ADC,
    INPUT
  );

  pinMode(
    CELL2_ADC,
    INPUT
  );


  // -----------------------------------------------
  // INITIAL SAFE STATE
  // -----------------------------------------------

  relayCommand =
    false;

  digitalWrite(
    RELAY_CONTROL,
    LOW
  );

  relayCommandTime =
    millis();

  digitalWrite(
    STATUS_LED,
    HIGH
  );

  currentState =
    NORMAL;

  stateEntryTime =
    millis();


  Serial.println(
    "[SYSTEM] State = NORMAL"
  );
}


// =================================================
// MAIN LOOP
// =================================================

void loop() {

  // ===============================================
  // FAULT TEST BUTTON
  // ===============================================

  if (digitalRead(FAULT_TEST_PIN)
      == LOW) {

    setFault(
      FAULT_COMMUNICATION,
      SOURCE_COMMUNICATION
    );


    if (currentState == NORMAL) {

      changeState(
        DEGRADED,
        activeFault.id
      );
    }
  }


  // ===============================================
  // STATE MACHINE
  // ===============================================

  switch (currentState) {

    case NORMAL:

      handleNormal();

      break;


    case DEGRADED:

      handleDegraded();

      break;


    case FAILSAFE:

      handleFailsafe();

      break;


    case SHUTDOWN:

      handleShutdown();

      break;
  }


  delay(100);
}