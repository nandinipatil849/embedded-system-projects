#ifndef FAULT_MANAGER_H
#define FAULT_MANAGER_H

#include <Arduino.h>

// =================================================
// SYSTEM STATES
// =================================================

enum SystemState {
  NORMAL,
  DEGRADED,
  FAILSAFE,
  SHUTDOWN
};

// =================================================
// FAULT IDs
// =================================================

enum FaultID {
  FAULT_NONE = 0,
  FAULT_CELL1_ADC,
  FAULT_CELL2_ADC,
  FAULT_ADC_FROZEN,
  FAULT_RELAY_MISMATCH,
  FAULT_COMMUNICATION,
  FAULT_UNKNOWN
};

// =================================================
// FAULT SOURCES
// =================================================

enum FaultSource {
  SOURCE_NONE,
  SOURCE_BATTERY_CELL1,
  SOURCE_BATTERY_CELL2,
  SOURCE_ADC,
  SOURCE_RELAY,
  SOURCE_COMMUNICATION,
  SOURCE_SYSTEM
};

// =================================================
// FAULT RECORD
// =================================================

struct FaultRecord {

  FaultID id;
  FaultSource source;
  bool active;

  unsigned long firstDetected;
  unsigned long lastDetected;
};

// =================================================
// GLOBAL VARIABLES
// =================================================

extern SystemState currentState;
extern FaultRecord activeFault;

extern unsigned long stateEntryTime;

// =================================================
// FUNCTIONS
// =================================================

String stateToString(SystemState state);

String faultToString(FaultID fault);

String sourceToString(FaultSource source);

void setFault(
  FaultID id,
  FaultSource source
);

void clearFault();

void logTransition(
  SystemState previous,
  SystemState next,
  FaultID fault
);

void changeState(
  SystemState nextState,
  FaultID fault
);

#endif