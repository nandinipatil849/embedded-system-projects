#include "FaultManager.h"

// =================================================
// GLOBAL VARIABLES
// =================================================

SystemState currentState = NORMAL;

FaultRecord activeFault = {
  FAULT_NONE,
  SOURCE_NONE,
  false,
  0,
  0
};

unsigned long stateEntryTime = 0;


// =================================================
// STATE TO STRING
// =================================================

String stateToString(SystemState state) {

  switch (state) {

    case NORMAL:
      return "NORMAL";

    case DEGRADED:
      return "DEGRADED";

    case FAILSAFE:
      return "FAILSAFE";

    case SHUTDOWN:
      return "SHUTDOWN";
  }

  return "UNKNOWN";
}


// =================================================
// FAULT TO STRING
// =================================================

String faultToString(FaultID fault) {

  switch (fault) {

    case FAULT_NONE:
      return "FAULT_NONE";

    case FAULT_CELL1_ADC:
      return "CELL1_ADC";

    case FAULT_CELL2_ADC:
      return "CELL2_ADC";

    case FAULT_ADC_FROZEN:
      return "ADC_FROZEN";

    case FAULT_RELAY_MISMATCH:
      return "RELAY_MISMATCH";

    case FAULT_COMMUNICATION:
      return "COMMUNICATION";

    case FAULT_UNKNOWN:
      return "UNKNOWN";
  }

  return "UNKNOWN";
}


// =================================================
// SOURCE TO STRING
// =================================================

String sourceToString(FaultSource source) {

  switch (source) {

    case SOURCE_NONE:
      return "NONE";

    case SOURCE_BATTERY_CELL1:
      return "BATTERY_CELL1";

    case SOURCE_BATTERY_CELL2:
      return "BATTERY_CELL2";

    case SOURCE_ADC:
      return "ADC";

    case SOURCE_RELAY:
      return "RELAY";

    case SOURCE_COMMUNICATION:
      return "COMMUNICATION";

    case SOURCE_SYSTEM:
      return "SYSTEM";
  }

  return "UNKNOWN";
}


// =================================================
// SET FAULT
// =================================================

void setFault(
  FaultID id,
  FaultSource source
) {

  // Same fault already active
  if (activeFault.active &&
      activeFault.id == id) {

    activeFault.lastDetected = millis();

    return;
  }

  activeFault.id = id;
  activeFault.source = source;
  activeFault.active = true;

  activeFault.firstDetected = millis();
  activeFault.lastDetected = millis();

  Serial.print("[FAULT DETECTED] ");

  Serial.print(
    faultToString(id)
  );

  Serial.print(" | SOURCE=");

  Serial.println(
    sourceToString(source)
  );
}


// =================================================
// CLEAR FAULT
// =================================================

void clearFault() {

  if (!activeFault.active) {
    return;
  }

  activeFault.id = FAULT_NONE;

  activeFault.source = SOURCE_NONE;

  activeFault.active = false;

  activeFault.firstDetected = 0;

  activeFault.lastDetected = 0;

  Serial.println("[FAULT CLEARED]");
}


// =================================================
// STRUCTURED STATE LOG
// =================================================

void logTransition(
  SystemState previous,
  SystemState next,
  FaultID fault
) {

  Serial.println();
  Serial.println("{");

  Serial.print("  \"timestamp_ms\": ");
  Serial.println(millis());

  Serial.print("  \"previous_state\": \"");
  Serial.print(
    stateToString(previous)
  );
  Serial.println("\",");

  Serial.print("  \"new_state\": \"");
  Serial.print(
    stateToString(next)
  );
  Serial.println("\",");

  Serial.print("  \"fault_id\": \"");
  Serial.print(
    faultToString(fault)
  );
  Serial.println("\",");

  Serial.print("  \"fault_source\": \"");
  Serial.print(
    sourceToString(activeFault.source)
  );
  Serial.println("\"");

  Serial.println("}");

  Serial.println();
}


// =================================================
// STATE CHANGE
// =================================================

void changeState(
  SystemState nextState,
  FaultID fault
) {

  // Ignore same state
  if (currentState == nextState) {
    return;
  }

  SystemState previousState =
    currentState;

  currentState =
    nextState;

  stateEntryTime =
    millis();

  logTransition(
    previousState,
    nextState,
    fault
  );
}