#ifndef PROTECTION_RELAY_H
#define PROTECTION_RELAY_H

#include <Arduino.h>

/* ============================================================
   Non-Blocking Protection Relay & Safety System
   ------------------------------------------------------------
   Pure state-machine + millis() timing design. update() must be
   called every loop() iteration; it internally rate-limits its
   own sampling, so calling it fast/often is always safe and
   never blocks.
   ============================================================ */

// ---- Sensor scaling ----
#define WINDOW_SIZE 8              // samples kept for rolling mean/stddev

// ---- Relay wiring polarity ----
// Wokwi's wokwi-relay-module: IN LOW energizes the coil (COM->NO).
// We treat "energized" as "closed / delivering power" (normal state).
#define RELAY_ACTIVE_LOW true

class ProtectionRelay {
public:
    enum State : uint8_t {
        NORMAL = 0,
        FAULT_PENDING,   // anomaly detected, debounce timer running, relay still closed
        TRIPPED,         // confirmed fault, relay open
        RECOVERING       // condition cleared, timed stabilization hold before reclosing
    };

    enum FaultReason : uint8_t {
        FAULT_NONE = 0,
        FAULT_OUT_OF_BOUNDS,   // reading outside the sensor's physically valid range
        FAULT_SENSOR_SPIKE,    // sustained implausible sample-to-sample jump
        FAULT_FROZEN_SENSOR,   // reading hasn't changed for too long
        FAULT_OVER_RANGE,      // valid reading, but above the trip threshold
        FAULT_UNDER_RANGE      // valid reading, but below the trip threshold
    };

    ProtectionRelay();

    // Call once in setup().
    void begin(uint8_t sensorPin, uint8_t relayPin,
               uint8_t ledNormalPin, uint8_t ledRecoveryPin, uint8_t ledFaultPin,
               float adcRefVoltage = 3.3f, float fullScaleVoltage = 30.0f);

    // Call every loop() iteration. Internally non-blocking / self-timed.
    void update();

    // --- External fault-injection hooks (wired to pushbuttons in sketch.ino) ---
    // While active, the reading is forced to a fixed captured value (simulates
    // a stuck ADC / broken wiper / dead sensor).
    void setFreezeInjection(bool active);
    // While active, an implausible offset is added to the reading each sample
    // (simulates EMI, a glitching ADC, or a bad connection).
    void setSpikeInjection(bool active);

    // --- Read-only status interface ---
    State        getState() const;
    FaultReason  getLastFault() const;
    float        getReading() const;      // last accepted (filtered) reading, in volts
    float        getNoiseFloor() const;    // rolling stddev over WINDOW_SIZE samples
    bool         isRelayClosed() const;
    unsigned long getStateElapsedMs() const;

    static const char* stateName(State s);
    static const char* faultName(FaultReason f);

private:
    // ---- pins ----
    uint8_t _sensorPin, _relayPin, _ledNormalPin, _ledRecoveryPin, _ledFaultPin;
    float   _adcRef, _fullScale;

    // ---- fault injection ----
    bool  _injectFreeze, _injectSpike;
    bool  _freezeCaptured;
    float _frozenValue;

    // ---- sampling / glitch filter ----
    unsigned long _lastSampleTime;
    float _lastFiltered;
    uint8_t _implausibleStreak;

    // ---- frozen-sensor tracking ----
    float _lastChangeRefValue;
    unsigned long _lastChangeTime;

    // ---- rolling statistics window ----
    float _window[WINDOW_SIZE];
    uint8_t _windowCount;
    uint8_t _windowIndex;

    // ---- state machine ----
    State _state;
    FaultReason _lastFault;
    unsigned long _stateEnteredTime;
    FaultReason _pendingReason;
    unsigned long _pendingStartTime;
    unsigned long _clearStartTime;
    unsigned long _tripStartTime;   // when TRIPPED was entered, for duration reporting

    // ---- LED blink (RECOVERING / FAULT_PENDING indicator) ----
    unsigned long _lastBlinkTime;
    bool _blinkOn;

    // ---- heartbeat log ----
    unsigned long _lastHeartbeatTime;

    // ---- professional event logging ----
    uint32_t _eventCount;      // sequential event/transition counter
    uint16_t _heartbeatCount;  // counts heartbeats for periodic dashboard

    float readSensorRaw();
    float applyGlitchFilter(float candidate);
    void  updateFrozenTracking(float v, unsigned long now);
    bool  isFrozen(unsigned long now) const;
    void  pushToWindow(float v);
    void  computeWindowStats(float &mean, float &stddev) const;
    FaultReason classify(float v, unsigned long now, float windowMean, float windowStddev) const;
    bool  isClear(float v, FaultReason reason) const;

    void  runStateMachine(FaultReason reason, float v, unsigned long now);
    void  transitionTo(State newState, FaultReason reason, float v, unsigned long now);
    void  setRelay(bool closed);
    void  updateLeds(unsigned long now);
    void  logTransition(State from, State to, FaultReason reason, float v, unsigned long now);
    void  logHeartbeat(float v, unsigned long now);
    void  printBanner();
    void  printDashboard(float v, float mean, float stddev, unsigned long now);
    static void formatUptime(unsigned long ms, char *buf, size_t bufSize);
};

#endif

