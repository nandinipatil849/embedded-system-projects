#include "ProtectionRelay.h"

/* ------------------------------------------------------------
   Tunable safety parameters. All timing is millis()-based;
   nothing here ever calls delay().
   ------------------------------------------------------------ */
static const unsigned long SAMPLE_INTERVAL_MS   = 50;    // 20 Hz sampling
static const unsigned long FAULT_DEBOUNCE_MS    = 300;   // anomaly must persist this long to trip
static const unsigned long FROZEN_TIMEOUT_MS    = 3000;  // no-change duration -> frozen fault
static const unsigned long RECOVERY_HOLD_MS     = 5000;  // must stay clear this long to reclose
static const unsigned long BLINK_INTERVAL_MS    = 250;
static const unsigned long HEARTBEAT_INTERVAL_MS = 2000;

static const float FROZEN_EPSILON_V      = 0.03f;  // min change to count as "alive"
static const float MAX_PHYSICAL_SLEW_V   = 6.0f;    // max plausible V change per sample (~120 V/s)
static const uint8_t SPIKE_CONFIRM_SAMPLES = 3;      // consecutive implausible samples to confirm a fault
static const float SPIKE_Z_SCORE         = 3.0f;    // statistical outlier threshold (std-devs from window mean)
static const float MIN_STDDEV_FOR_Z_TEST = 0.15f;   // floor for stddev so a near-silent window (stddev~0)
                                                       // doesn't make an ordinary reading register as "infinite sigma"

// Operating thresholds, in the simulated 0-30V "line voltage" scale.
// Trip/clear pairs are intentionally offset from each other -- this is the
// hysteresis band that prevents chatter right at the boundary.
static const float SENSOR_MIN_V  = 0.0f;
static const float SENSOR_MAX_V  = 30.0f;
static const float TRIP_OVER_V   = 22.0f;
static const float CLEAR_OVER_V  = 21.0f;   // must drop BELOW this (not just below trip) to be "clear"
static const float TRIP_UNDER_V  = 8.0f;
static const float CLEAR_UNDER_V = 9.0f;    // must rise ABOVE this to be "clear"

static const float SPIKE_INJECT_OFFSET_V = 15.0f; // test-only offset used by the SPIKE fault button

ProtectionRelay::ProtectionRelay() {
    _sensorPin = _relayPin = _ledNormalPin = _ledRecoveryPin = _ledFaultPin = 0;
    _adcRef = 3.3f;
    _fullScale = 30.0f;

    _injectFreeze = _injectSpike = false;
    _freezeCaptured = false;
    _frozenValue = 0;

    _lastSampleTime = 0;
    _lastFiltered = 0;
    _implausibleStreak = 0;

    _lastChangeRefValue = 0;
    _lastChangeTime = 0;

    for (uint8_t i = 0; i < WINDOW_SIZE; i++) _window[i] = 0;
    _windowCount = 0;
    _windowIndex = 0;

    _state = NORMAL;
    _lastFault = FAULT_NONE;
    _stateEnteredTime = 0;
    _pendingReason = FAULT_NONE;
    _pendingStartTime = 0;
    _clearStartTime = 0;
    _tripStartTime = 0;

    _lastBlinkTime = 0;
    _blinkOn = false;
    _lastHeartbeatTime = 0;

    _eventCount = 0;
    _heartbeatCount = 0;
}

void ProtectionRelay::begin(uint8_t sensorPin, uint8_t relayPin,
                             uint8_t ledNormalPin, uint8_t ledRecoveryPin, uint8_t ledFaultPin,
                             float adcRefVoltage, float fullScaleVoltage) {
    _sensorPin = sensorPin;
    _relayPin = relayPin;
    _ledNormalPin = ledNormalPin;
    _ledRecoveryPin = ledRecoveryPin;
    _ledFaultPin = ledFaultPin;
    _adcRef = adcRefVoltage;
    _fullScale = fullScaleVoltage;

    pinMode(_sensorPin, INPUT);
    pinMode(_relayPin, OUTPUT);
    pinMode(_ledNormalPin, OUTPUT);
    pinMode(_ledRecoveryPin, OUTPUT);
    pinMode(_ledFaultPin, OUTPUT);

#if defined(ARDUINO_ARCH_ESP32)
    analogReadResolution(12);
#endif

    unsigned long now = millis();
    _lastSampleTime = now;
    _stateEnteredTime = now;
    _lastHeartbeatTime = now;

    // Prime the filter/frozen-tracker with a real first reading so the very
    // first update() cycle doesn't see a false 0V->reading "jump".
    float v = readSensorRaw();
    _lastFiltered = v;
    _lastChangeRefValue = v;
    _lastChangeTime = now;
    pushToWindow(v);

    setRelay(true); // start closed / normal
    updateLeds(now);

    printBanner();
}

/* ---------------------- Startup banner ---------------------- */

void ProtectionRelay::printBanner() {
    Serial.println();
    Serial.println(F("======================================================================"));
    Serial.println(F("   PROTECTION RELAY & SAFETY SYSTEM"));
    Serial.printf ("   Firmware v1.1  |  non-blocking  |  built %s %s\n", __DATE__, __TIME__);
    Serial.println(F("======================================================================"));
    Serial.printf (" %-23s %s\n", "Sample rate", "20 Hz (50 ms)");
    Serial.printf (" %-23s %lu ms\n", "Fault debounce", (unsigned long)FAULT_DEBOUNCE_MS);
    Serial.printf (" %-23s %lu ms\n", "Frozen-sensor timeout", (unsigned long)FROZEN_TIMEOUT_MS);
    Serial.printf (" %-23s %lu ms\n", "Recovery hold", (unsigned long)RECOVERY_HOLD_MS);
    Serial.println(F("----------------------------------------------------------------------"));
    Serial.printf (" %-23s %5.2fV .. %5.2fV\n", "Normal band", CLEAR_UNDER_V, CLEAR_OVER_V);
    Serial.printf (" %-23s > %5.2fV   (clears < %5.2fV)\n", "Trip: over-voltage", TRIP_OVER_V, CLEAR_OVER_V);
    Serial.printf (" %-23s < %5.2fV   (clears > %5.2fV)\n", "Trip: under-voltage", TRIP_UNDER_V, CLEAR_UNDER_V);
    Serial.printf (" %-23s %5.2fV .. %5.2fV\n", "Valid sensor range", SENSOR_MIN_V, SENSOR_MAX_V);
    Serial.println(F("======================================================================"));
    Serial.println(F("  EVENT#   UPTIME         STATE TRANSITION                   READING    REASON"));
    Serial.println(F("----------------------------------------------------------------------"));
}

void ProtectionRelay::setFreezeInjection(bool active) { _injectFreeze = active; }
void ProtectionRelay::setSpikeInjection(bool active)   { _injectSpike = active; }

/* ---------------------- Sensor acquisition ---------------------- */

float ProtectionRelay::readSensorRaw() {
    int raw = analogRead(_sensorPin);
    // analogRead() already returns 0-4095 spanning the full ADC input range
    // (_adcRef volts at the pin), so the fraction below maps directly onto
    // the simulated 0-_fullScale "line voltage" scale. _adcRef is kept as a
    // begin() parameter for documentation and for real-hardware variants
    // that read actual pin millivolts instead of a simulated full-scale value.
    float fraction = raw / 4095.0f;
    float v = fraction * _fullScale;

    if (_injectFreeze) {
        // Genuine stuck-sensor simulation: hold the exact captured value,
        // with NO dither, so a held FREEZE button correctly trips
        // FAULT_FROZEN_SENSOR after FROZEN_TIMEOUT_MS.
        if (!_freezeCaptured) {
            _frozenValue = v;
            _freezeCaptured = true;
        }
        v = _frozenValue;
    } else {
        _freezeCaptured = false;
        // Wokwi's potentiometer outputs a perfectly exact, noiseless value
        // when untouched -- unlike a real ADC/sensor, which always has some
        // thermal/quantization noise. Without this small synthetic dither,
        // simply not touching the pot for 3s would itself look "frozen" and
        // trip a false fault. Real hardware supplies its own natural noise
        // and would not need this line.
        v += 0.05f * sinf(millis() / 500.0f);
    }

    if (_injectSpike) {
        v += SPIKE_INJECT_OFFSET_V; // deliberately implausible jump for testing
        // Clamp to stay inside the physically valid sensor range. Real EMI/
        // glitch events are implausible *jumps*, not necessarily out-of-bounds
        // readings -- without this clamp, injecting the spike near the top of
        // the scale would misclassify as FAULT_OUT_OF_BOUNDS instead of the
        // intended FAULT_SENSOR_SPIKE, making the test non-deterministic.
        if (v > SENSOR_MAX_V - 0.01f) v = SENSOR_MAX_V - 0.01f;
        if (v < SENSOR_MIN_V + 0.01f) v = SENSOR_MIN_V + 0.01f;
    }

    return v;
}

// Rejects a SINGLE-sample outlier that isn't confirmed by subsequent
// samples (sensor noise / EMI blip), while still passing through a
// SUSTAINED implausible jump (>= SPIKE_CONFIRM_SAMPLES in a row) so it can
// be classified as a genuine sensor fault. This is the mechanism that
// distinguishes a one-off glitch from a real (if fast) condition.
float ProtectionRelay::applyGlitchFilter(float candidate) {
    float delta = fabsf(candidate - _lastFiltered);

    if (delta > MAX_PHYSICAL_SLEW_V) {
        if (_implausibleStreak < 250) _implausibleStreak++;
        if (_implausibleStreak < SPIKE_CONFIRM_SAMPLES) {
            // Not yet confirmed: suppress this sample, hold last good value.
            return _lastFiltered;
        }
        // Confirmed sustained jump: accept it into the stream so classify()
        // can flag FAULT_SENSOR_SPIKE.
        _lastFiltered = candidate;
        return candidate;
    }

    _implausibleStreak = 0;
    _lastFiltered = candidate;
    return candidate;
}

void ProtectionRelay::updateFrozenTracking(float v, unsigned long now) {
    if (fabsf(v - _lastChangeRefValue) > FROZEN_EPSILON_V) {
        _lastChangeRefValue = v;
        _lastChangeTime = now;
    }
}

bool ProtectionRelay::isFrozen(unsigned long now) const {
    return (now - _lastChangeTime) >= FROZEN_TIMEOUT_MS;
}

void ProtectionRelay::pushToWindow(float v) {
    _window[_windowIndex] = v;
    _windowIndex = (_windowIndex + 1) % WINDOW_SIZE;
    if (_windowCount < WINDOW_SIZE) _windowCount++;
}

void ProtectionRelay::computeWindowStats(float &mean, float &stddev) const {
    if (_windowCount == 0) { mean = 0; stddev = 0; return; }
    float sum = 0;
    for (uint8_t i = 0; i < _windowCount; i++) sum += _window[i];
    mean = sum / _windowCount;

    float sqSum = 0;
    for (uint8_t i = 0; i < _windowCount; i++) {
        float d = _window[i] - mean;
        sqSum += d * d;
    }
    stddev = sqrtf(sqSum / _windowCount);
}

/* ---------------------- Classification ---------------------- */

// Combines TWO independent tests before confirming a sensor-glitch fault:
//   1) slew-rate confirmation (applyGlitchFilter): the jump must be
//      physically implausible AND sustained for SPIKE_CONFIRM_SAMPLES
//      consecutive samples -- this alone rejects single-sample noise.
//   2) statistical confirmation: the accepted value must ALSO be a
//      genuine outlier relative to the rolling window's mean/stddev
//      (a z-score beyond SPIKE_Z_SCORE), computed from the window as it
//      stood BEFORE this sample was added (see update()), so the test
//      isn't circularly influenced by the very sample it's judging.
// Requiring both to agree is what makes this a real statistical/window-
// based discriminator rather than a plain sample counter.
ProtectionRelay::FaultReason ProtectionRelay::classify(float v, unsigned long now,
                                                        float windowMean, float windowStddev) const {
    // Priority order: hard invalid reading > confirmed sensor glitch >
    // frozen sensor > normal over/under-range trip.
    if (v < SENSOR_MIN_V || v > SENSOR_MAX_V) return FAULT_OUT_OF_BOUNDS;

    if (_implausibleStreak >= SPIKE_CONFIRM_SAMPLES) {
        if (_windowCount < WINDOW_SIZE) {
            // Window hasn't filled yet (e.g. right after boot) -- fall back
            // to the slew-only confirmation rather than block on stats we
            // don't have enough history to trust yet.
            return FAULT_SENSOR_SPIKE;
        }
        float stddevFloor = fmaxf(windowStddev, MIN_STDDEV_FOR_Z_TEST);
        float z = fabsf(v - windowMean) / stddevFloor;
        if (z > SPIKE_Z_SCORE) {
            return FAULT_SENSOR_SPIKE;
        }
        // Slew-confirmed but not a statistical outlier against recent
        // history -- extremely rare in practice, but fall through to the
        // normal range checks below rather than silently dropping it.
    }

    if (isFrozen(now)) return FAULT_FROZEN_SENSOR;
    if (v > TRIP_OVER_V) return FAULT_OVER_RANGE;
    if (v < TRIP_UNDER_V) return FAULT_UNDER_RANGE;
    return FAULT_NONE;
}

bool ProtectionRelay::isClear(float v, FaultReason reason) const {
    if (reason != FAULT_NONE) return false;
    if (v > CLEAR_OVER_V) return false;
    if (v < CLEAR_UNDER_V) return false;
    return true;
}

/* ---------------------- State machine ---------------------- */

void ProtectionRelay::update() {
    unsigned long now = millis();

    if (now - _lastSampleTime < SAMPLE_INTERVAL_MS) {
        updateLeds(now); // keep blink animation smooth between samples
        return;           // non-blocking: nothing else to do yet
    }
    _lastSampleTime = now;

    float raw = readSensorRaw();
    float v = applyGlitchFilter(raw);

    updateFrozenTracking(v, now);

    // Snapshot the window's statistics BEFORE this sample is added, so
    // classify() judges "is v an outlier?" against prior history only --
    // not against a window that already includes the very value in question.
    float windowMean, windowStddev;
    computeWindowStats(windowMean, windowStddev);

    FaultReason reason = classify(v, now, windowMean, windowStddev);

    pushToWindow(v);

    runStateMachine(reason, v, now);
    updateLeds(now);
    logHeartbeat(v, now);
}

void ProtectionRelay::runStateMachine(FaultReason reason, float v, unsigned long now) {
    switch (_state) {

        case NORMAL:
            if (reason != FAULT_NONE) {
                _pendingReason = reason;
                _pendingStartTime = now;
                transitionTo(FAULT_PENDING, reason, v, now);
            }
            break;

        case FAULT_PENDING:
            if (reason == FAULT_NONE) {
                // Transient cleared before the debounce window elapsed --
                // this is exactly the anti-chatter behavior: no relay
                // switching event occurs for a blip shorter than 300ms.
                transitionTo(NORMAL, FAULT_NONE, v, now);
            } else {
                if (reason != _pendingReason) {
                    _pendingReason = reason;
                    _pendingStartTime = now; // restart debounce for the new reason
                }
                if (now - _pendingStartTime >= FAULT_DEBOUNCE_MS) {
                    transitionTo(TRIPPED, reason, v, now);
                }
            }
            break;

        case TRIPPED:
            if (isClear(v, reason)) {
                if (_clearStartTime == 0) _clearStartTime = now;
                if (now - _clearStartTime >= FAULT_DEBOUNCE_MS) {
                    transitionTo(RECOVERING, FAULT_NONE, v, now);
                }
            } else {
                _clearStartTime = 0;
            }
            break;

        case RECOVERING:
            if (!isClear(v, reason)) {
                transitionTo(TRIPPED, reason, v, now); // abort: back to tripped immediately
            } else if (now - _stateEnteredTime >= RECOVERY_HOLD_MS) {
                transitionTo(NORMAL, FAULT_NONE, v, now);
            }
            break;
    }
}

void ProtectionRelay::transitionTo(State newState, FaultReason reason, float v, unsigned long now) {
    State old = _state;

    logTransition(old, newState, reason, v, now);

    _state = newState;
    _lastFault = reason;
    _stateEnteredTime = now;

    if (newState == TRIPPED) {
        setRelay(false);
        _clearStartTime = 0;
        if (old != TRIPPED) _tripStartTime = now;
    } else if (newState == NORMAL) {
        setRelay(true);
        _pendingReason = FAULT_NONE;
        _clearStartTime = 0;
    }
    // FAULT_PENDING and RECOVERING keep the relay in its current position
    // (closed for FAULT_PENDING, open for RECOVERING) -- set at the moment
    // TRIPPED/NORMAL was entered.
}

void ProtectionRelay::setRelay(bool closed) {
#if RELAY_ACTIVE_LOW
    digitalWrite(_relayPin, closed ? LOW : HIGH);
#else
    digitalWrite(_relayPin, closed ? HIGH : LOW);
#endif
}

void ProtectionRelay::updateLeds(unsigned long now) {
    if (now - _lastBlinkTime >= BLINK_INTERVAL_MS) {
        _lastBlinkTime = now;
        _blinkOn = !_blinkOn;
    }

    switch (_state) {
        case NORMAL:
            digitalWrite(_ledNormalPin, HIGH);
            digitalWrite(_ledRecoveryPin, LOW);
            digitalWrite(_ledFaultPin, LOW);
            break;
        case FAULT_PENDING:
            digitalWrite(_ledNormalPin, LOW);
            digitalWrite(_ledRecoveryPin, _blinkOn ? HIGH : LOW); // fast warning blink
            digitalWrite(_ledFaultPin, LOW);
            break;
        case TRIPPED:
            digitalWrite(_ledNormalPin, LOW);
            digitalWrite(_ledRecoveryPin, LOW);
            digitalWrite(_ledFaultPin, HIGH);
            break;
        case RECOVERING:
            digitalWrite(_ledNormalPin, LOW);
            digitalWrite(_ledRecoveryPin, _blinkOn ? HIGH : LOW); // slower "almost there" blink
            digitalWrite(_ledFaultPin, LOW);
            break;
    }
}

/* ---------------------- Logging ---------------------- */

void ProtectionRelay::formatUptime(unsigned long ms, char *buf, size_t bufSize) {
    unsigned long totalSeconds = ms / 1000UL;
    unsigned int  millisPart   = ms % 1000UL;
    unsigned int  hours        = totalSeconds / 3600UL;
    unsigned int  minutes      = (totalSeconds % 3600UL) / 60UL;
    unsigned int  seconds      = totalSeconds % 60UL;
    snprintf(buf, bufSize, "%02u:%02u:%02u.%03u", hours, minutes, seconds, millisPart);
}

// One line per state transition, real fixed-width columns (not a
// pre-built string) so the log stays perfectly aligned in a raw Serial
// Monitor. FAULT trips and recovery aborts get a divider so they stand
// out when scanning a long session log. Leaving TRIPPED also reports how
// long the fault was actually active -- standard practice for a
// protection relay's event recorder.
void ProtectionRelay::logTransition(State from, State to, FaultReason reason, float v, unsigned long now) {
    _eventCount++;

    char uptime[16];
    formatUptime(now, uptime, sizeof(uptime));

    bool highlight = (to == TRIPPED) || (from == TRIPPED);
    if (highlight) Serial.println(F("----------------------------------------------------------------------"));

    Serial.printf("  #%05lu   %s   %-14s -> %-14s   %6.2fV   %s\n",
                  (unsigned long)_eventCount, uptime,
                  stateName(from), stateName(to), v, faultName(reason));

    if (from == TRIPPED && to != TRIPPED) {
        char dur[16];
        formatUptime(now - _tripStartTime, dur, sizeof(dur));
        Serial.printf("            fault duration: %s\n", dur);
    }

    if (highlight) Serial.println(F("----------------------------------------------------------------------"));
}

// Periodic status line -- same column layout as the transition log so the
// two interleave cleanly. Every 5th heartbeat also prints a fuller
// one-line dashboard with noise-floor and relay position, so a long
// idle NORMAL period still gives visibility without flooding the log.
void ProtectionRelay::logHeartbeat(float v, unsigned long now) {
    if (now - _lastHeartbeatTime < HEARTBEAT_INTERVAL_MS) return;
    _lastHeartbeatTime = now;
    _heartbeatCount++;

    float mean, stddev;
    computeWindowStats(mean, stddev);

    if (_heartbeatCount % 5 == 0) {
        printDashboard(v, mean, stddev, now);
    } else {
        char uptime[16];
        formatUptime(now, uptime, sizeof(uptime));
        Serial.printf("  .......   %s   state=%-14s              %6.2fV\n",
                      uptime, stateName(_state), v);
    }
}

void ProtectionRelay::printDashboard(float v, float mean, float stddev, unsigned long now) {
    char uptime[16];
    formatUptime(now, uptime, sizeof(uptime));
    char stateElapsed[16];
    formatUptime(getStateElapsedMs(), stateElapsed, sizeof(stateElapsed));

    Serial.println(F("  ...................................................................."));
    Serial.printf ("  STATUS    uptime=%s   state=%-14s  in-state=%s\n",
                   uptime, stateName(_state), stateElapsed);
    Serial.printf ("            reading=%6.2fV  mean=%6.2fV  noise(sigma)=%5.3fV  relay=%s\n",
                   v, mean, stddev, isRelayClosed() ? "CLOSED" : "OPEN");
    Serial.println(F("  ...................................................................."));
}

/* ---------------------- Public getters ---------------------- */

ProtectionRelay::State ProtectionRelay::getState() const { return _state; }
ProtectionRelay::FaultReason ProtectionRelay::getLastFault() const { return _lastFault; }
float ProtectionRelay::getReading() const { return _lastFiltered; }

float ProtectionRelay::getNoiseFloor() const {
    float mean, stddev;
    computeWindowStats(mean, stddev);
    return stddev;
}

bool ProtectionRelay::isRelayClosed() const {
    return (_state == NORMAL || _state == FAULT_PENDING);
}

unsigned long ProtectionRelay::getStateElapsedMs() const {
    return millis() - _stateEnteredTime;
}

const char* ProtectionRelay::stateName(State s) {
    switch (s) {
        case NORMAL:        return "NORMAL";
        case FAULT_PENDING: return "FAULT_PENDING";
        case TRIPPED:        return "TRIPPED";
        case RECOVERING:     return "RECOVERING";
    }
    return "UNKNOWN";
}

const char* ProtectionRelay::faultName(FaultReason f) {
    switch (f) {
        case FAULT_NONE:          return "NONE";
        case FAULT_OUT_OF_BOUNDS: return "OUT_OF_BOUNDS";
        case FAULT_SENSOR_SPIKE:  return "SENSOR_SPIKE";
        case FAULT_FROZEN_SENSOR: return "FROZEN_SENSOR";
        case FAULT_OVER_RANGE:    return "OVER_RANGE";
        case FAULT_UNDER_RANGE:   return "UNDER_RANGE";
    }
    return "UNKNOWN";
}

