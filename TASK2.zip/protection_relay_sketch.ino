/* ===================================================================
   Non-Blocking Protection Relay & Safety System - Wokwi / ESP32 Demo
   ===================================================================
   A potentiometer simulates a monitored line voltage (0-30V scale).
   Two pushbuttons inject simulated sensor faults for testing:
     - FREEZE button (GPIO25): forces the reading to stay fixed,
       simulating a stuck ADC / dead sensor.
     - SPIKE button (GPIO26): adds an implausible offset each sample,
       simulating EMI / a glitching connection.

   IMPORTANT: There is no delay() anywhere in this sketch or in
   ProtectionRelay. loop() runs as fast as possible; all timing is
   done with millis() comparisons inside ProtectionRelay::update().
   =================================================================== */

#include "ProtectionRelay.h"

// ---- Pin assignments (see wiring table in the project README) ----
const uint8_t PIN_SENSOR      = 34;
const uint8_t PIN_BTN_FREEZE  = 25;
const uint8_t PIN_BTN_SPIKE   = 26;
const uint8_t PIN_RELAY       = 2;
const uint8_t PIN_LED_NORMAL  = 4;   // green
const uint8_t PIN_LED_RECOVER = 5;   // yellow
const uint8_t PIN_LED_FAULT   = 18;  // red

ProtectionRelay relay;

void setup() {
  Serial.begin(115200);
  delay(300); // one-time startup pause only, NOT part of the control loop

  pinMode(PIN_BTN_FREEZE, INPUT_PULLUP);
  pinMode(PIN_BTN_SPIKE, INPUT_PULLUP);

  // fullScaleVoltage = 30V represents a simulated protected line;
  // on real hardware, replace with your actual sensor's voltage divider.
  relay.begin(PIN_SENSOR, PIN_RELAY, PIN_LED_NORMAL, PIN_LED_RECOVER, PIN_LED_FAULT,
              3.3f, 30.0f);

  // relay.begin() already prints the full startup banner (thresholds,
  // timing, and the event-log column header). We only add the operator
  // controls reference here, formatted to match that log.
  Serial.println(F("  CONTROLS"));
  Serial.println(F("    Potentiometer  -> simulated line voltage"));
  Serial.println(F("    FREEZE (GPIO25, hold)  -> inject stuck-sensor fault"));
  Serial.println(F("    SPIKE  (GPIO26, hold)  -> inject implausible-jump fault"));
  Serial.println(F("----------------------------------------------------------------------"));
}

void loop() {
  // Active-low buttons (INPUT_PULLUP): pressed = LOW.
  bool freezeHeld = (digitalRead(PIN_BTN_FREEZE) == LOW);
  bool spikeHeld  = (digitalRead(PIN_BTN_SPIKE) == LOW);

  relay.setFreezeInjection(freezeHeld);
  relay.setSpikeInjection(spikeHeld);

  relay.update(); // non-blocking; internally rate-limited to 20 Hz sampling

  // No delay() here. loop() is free to run as fast as the MCU allows,
  // which is what "fully non-blocking" means in practice: the button
  // reads above and relay.update() below both execute every pass with
  // no busy-waiting, so the system stays responsive under continuous
  // fault injection (rapid button mashing, fast pot movement, etc.)
  // without ever missing a state transition or needing a reset.
}

