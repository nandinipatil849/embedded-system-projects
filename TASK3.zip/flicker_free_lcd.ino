#include <Wire.h>
#include <LiquidCrystal_I2C.h>

/* ----------------------------- HARDWARE ----------------------------- */
#define LCD_ADDR            0x27
#define LCD_COLS            16
#define LCD_ROWS            2
LiquidCrystal_I2C lcd(LCD_ADDR, LCD_COLS, LCD_ROWS);

// ESP32 notes:
//  - GPIO34/35 are ADC1, input-only -> ideal for the two potentiometers.
//  - GPIO16/17 are general-purpose, safe (not boot-strap / not UART0).
//  - GPIO4 is a safe general-purpose output for the fault LED.
//  - GPIO0, 2, 12, 15 (boot-strapping) and GPIO1, 3 (UART0/Serial) are
//    deliberately avoided.
//  - I2C on ESP32 defaults to SDA=GPIO21, SCL=GPIO22 (set explicitly below).
#define PIN_BATTERY_ADC     34   // potentiometer -> simulated battery %
#define PIN_TELEMETRY_ADC   35   // potentiometer -> simulated temperature
#define PIN_FAULT_TRIGGER   16   // push button -> GND (INPUT_PULLUP)
#define PIN_FAULT_CLEAR     17   // push button -> GND (INPUT_PULLUP)
#define PIN_FAULT_LED       4    // fault indicator LED (through resistor)
#define I2C_SDA_PIN         21
#define I2C_SCL_PIN         22
#define ADC_MAX_VALUE       4095 // ESP32 ADC is 12-bit (0-4095), not 10-bit

/* ------------------------------ TIMING ------------------------------ */
const unsigned long DISPLAY_TICK_MS   = 200;    // buffer rebuild / diff rate
const unsigned long PAGE_ROTATE_MS    = 3000;   // page dwell time
const unsigned long DEBOUNCE_MS       = 40;     // mechanical button debounce
const int  TEMP_FAULT_THRESHOLD_C     = 80;     // auto-trip fault condition

/* ============================ DISPLAY ENGINE =========================
 * Two character buffers are kept:
 *   shadowBuf -> what is CURRENTLY physically shown on the glass
 *   frameBuf  -> what SHOULD be shown after the next page render
 * lcdCommitFrame() walks both buffers cell-by-cell; the LCD cursor is
 * only moved and a byte only written when a mismatch is found. This is
 * what removes the clear+redraw flicker entirely.
 * =====================================================================*/
char shadowBuf[LCD_ROWS][LCD_COLS + 1];
char frameBuf[LCD_ROWS][LCD_COLS + 1];
bool shadowValid = false;

void lcdEngineInit() {
  for (uint8_t r = 0; r < LCD_ROWS; r++) {
    memset(shadowBuf[r], ' ', LCD_COLS);
    shadowBuf[r][LCD_COLS] = '\0';
  }
  shadowValid = false;
}

void frameClear() {
  for (uint8_t r = 0; r < LCD_ROWS; r++) {
    memset(frameBuf[r], ' ', LCD_COLS);
    frameBuf[r][LCD_COLS] = '\0';
  }
}

// Writes a string into the frame buffer at (row, col). Truncates safely.
void frameWrite(uint8_t row, uint8_t col, const char *s) {
  if (row >= LCD_ROWS) return;
  uint8_t i = 0;
  while (s[i] != '\0' && (col + i) < LCD_COLS) {
    frameBuf[row][col + i] = s[i];
    i++;
  }
}

// Pushes only the CHANGED cells to the physical LCD.
void lcdCommitFrame() {
  for (uint8_t r = 0; r < LCD_ROWS; r++) {
    for (uint8_t c = 0; c < LCD_COLS; c++) {
      char ch = frameBuf[r][c];
      if (!shadowValid || shadowBuf[r][c] != ch) {
        lcd.setCursor(c, r);
        lcd.write((uint8_t)ch);
        shadowBuf[r][c] = ch;
      }
    }
  }
  shadowValid = true;
}

/* ============================ APP STATE =============================*/
enum Page { PAGE_BATTERY = 0, PAGE_SYSTEM, PAGE_TELEMETRY, NUM_PAGES };
uint8_t currentPage = PAGE_BATTERY;

bool faultActive = false;
uint8_t faultCode = 0;   // 1 = manual trigger, 2 = over-temperature

unsigned long lastPageRotate   = 0;
unsigned long lastDisplayTick  = 0;
unsigned long lastTriggerEdgeT = 0;
unsigned long lastClearEdgeT   = 0;
int prevTriggerState = HIGH;
int prevClearState   = HIGH;

/* ============================ PAGE RENDERERS =========================*/
void renderBatteryPage() {
  int raw = analogRead(PIN_BATTERY_ADC);
  int pct = map(raw, 0, ADC_MAX_VALUE, 0, 100);

  char line0[17];
  snprintf(line0, sizeof(line0), "BATTERY STATUS");
  frameWrite(0, 0, line0);

  // simple 10-segment bar graph + numeric percentage
  char bar[11];
  int filled = map(pct, 0, 100, 0, 10);
  for (int i = 0; i < 10; i++) bar[i] = (i < filled) ? '#' : '-';
  bar[10] = '\0';

  char line1[17];
  snprintf(line1, sizeof(line1), "%3d%%[%s]", pct, bar);
  frameWrite(1, 0, line1);
}

void renderSystemPage() {
  frameWrite(0, 0, "SYSTEM STATE");

  unsigned long s = millis() / 1000;
  unsigned int hh = (s / 3600) % 24;
  unsigned int mm = (s / 60) % 60;
  unsigned int ss = s % 60;

  const char *state = "RUN";
  if (s < 5) state = "INIT";  // brief startup phase, then RUN

  char line1[17];
  snprintf(line1, sizeof(line1), "%-6s UP%02u:%02u:%02u", state, hh, mm, ss);
  frameWrite(1, 0, line1);
}

void renderTelemetryPage() {
  frameWrite(0, 0, "TELEMETRY");

  int raw = analogRead(PIN_TELEMETRY_ADC);
  int tempC = map(raw, 0, ADC_MAX_VALUE, 20, 95);  // simulated sensor range

  char line1[17];
  snprintf(line1, sizeof(line1), "TEMP: %3dC", tempC);
  frameWrite(1, 0, line1);
}

void renderFaultPage() {
  frameWrite(0, 0, "*** FAULT ***");

  const char *msg = "UNKNOWN";
  if (faultCode == 1) msg = "MANUAL TRIP";
  else if (faultCode == 2) msg = "OVER TEMP";

  char line1[17];
  snprintf(line1, sizeof(line1), "%-11s CLR", msg);
  frameWrite(1, 0, line1);
}

/* ============================ FAULT LOGIC ============================*/
void enterFault(uint8_t code) {
  if (!faultActive) {
    faultActive = true;
    shadowValid = false;   // force a full, immediate repaint of fault page
  }
  faultCode = code;
}

void clearFault() {
  faultActive = false;
  faultCode = 0;
  shadowValid = false;     // force a full repaint of the resumed page
  lastPageRotate = millis(); // restart rotation timer cleanly
}

// Debounced edge-detect on both buttons; auto over-temperature trip.
void handleFaultInputs(unsigned long now) {
  int trig = digitalRead(PIN_FAULT_TRIGGER);
  if (trig != prevTriggerState && (now - lastTriggerEdgeT) > DEBOUNCE_MS) {
    lastTriggerEdgeT = now;
    prevTriggerState = trig;
    if (trig == LOW) enterFault(1);   // pressed -> active LOW
  }

  int clr = digitalRead(PIN_FAULT_CLEAR);
  if (clr != prevClearState && (now - lastClearEdgeT) > DEBOUNCE_MS) {
    lastClearEdgeT = now;
    prevClearState = clr;
    if (clr == LOW) clearFault();     // pressed -> active LOW
  }

  // Automatic critical condition: over-temperature latches a fault too.
  int raw = analogRead(PIN_TELEMETRY_ADC);
  int tempC = map(raw, 0, ADC_MAX_VALUE, 20, 95);
  if (tempC >= TEMP_FAULT_THRESHOLD_C && !faultActive) {
    enterFault(2);
  }
}

/* ============================ DISPLAY DRIVER ==========================*/
void updateDisplay() {
  frameClear();
  if (faultActive) {
    renderFaultPage();
  } else {
    switch (currentPage) {
      case PAGE_BATTERY:   renderBatteryPage();   break;
      case PAGE_SYSTEM:    renderSystemPage();    break;
      case PAGE_TELEMETRY: renderTelemetryPage(); break;
    }
  }
  lcdCommitFrame();
}

/* ================================ SETUP ===============================*/
void setup() {
  Serial.begin(115200);

  pinMode(PIN_FAULT_TRIGGER, INPUT_PULLUP);
  pinMode(PIN_FAULT_CLEAR,   INPUT_PULLUP);
  pinMode(PIN_FAULT_LED,     OUTPUT);

  analogReadResolution(12);           // explicit: 0-4095 (ESP32 default anyway)
  Wire.begin(I2C_SDA_PIN, I2C_SCL_PIN); // ESP32 needs explicit SDA/SCL pins

  lcd.init();
  lcd.backlight();
  lcd.clear();          // ONE clear allowed: at power-up only
  lcdEngineInit();

  prevTriggerState = digitalRead(PIN_FAULT_TRIGGER);
  prevClearState   = digitalRead(PIN_FAULT_CLEAR);

  lastPageRotate  = millis();
  lastDisplayTick = millis();
}

/* ================================ LOOP =================================*/
void loop() {
  unsigned long now = millis();

  handleFaultInputs(now);

  // Non-blocking page rotation timer (frozen while a fault is active)
  if (!faultActive && (now - lastPageRotate >= PAGE_ROTATE_MS)) {
    lastPageRotate = now;
    currentPage = (currentPage + 1) % NUM_PAGES;
  }

  // Non-blocking display refresh tick
  if (now - lastDisplayTick >= DISPLAY_TICK_MS) {
    lastDisplayTick = now;
    updateDisplay();
  }

  digitalWrite(PIN_FAULT_LED, faultActive ? HIGH : LOW);
}

