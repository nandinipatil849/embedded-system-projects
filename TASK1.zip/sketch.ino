/* ===================================================================
   Modular BMS Engine - Wokwi / ESP32 Demo
   ===================================================================
   4 potentiometers simulate 4 battery cells (0 - 3.3 V each).
   To scale to more cells:
     1. Change NUM_CELLS in BMS.h
     2. Extend cellPins[] below to match
     3. Wire more ADC-capable pins (or add an analog mux, see report)
   =================================================================== */

#include "BMS.h"

// One ADC pin per cell. ESP32 ADC1 pins (work fine even with WiFi on).
const uint8_t cellPins[NUM_CELLS] = {34, 35, 32, 33};

BMS bms;

void setup() {
  Serial.begin(115200);
  delay(300);

  // dividerRatio = 1.0 because in simulation the potentiometer already
  // outputs 0-3.3V directly into the ADC (no external divider needed).
  // On REAL hardware with 4.2V cells, use a resistor divider and set
  // dividerRatio accordingly (see wiring notes in the report).
  bms.begin(cellPins, 3.3, 1.0);

  Serial.println(F("Modular BMS Engine Initialized"));
  Serial.print(F("Monitoring "));
  Serial.print(NUM_CELLS);
  Serial.println(F(" cells"));
}

void loop() {
  bms.update();
  bms.printStatus();
  delay(1000); // 1 Hz sampling rate
}
