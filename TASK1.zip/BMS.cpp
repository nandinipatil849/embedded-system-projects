#include "BMS.h"

/* ------------------------------------------------------------
   Approximate Li-ion (NMC) open-circuit-voltage vs SoC curve.
   Used only to *estimate* SoC from voltage. Replace with a
   coulomb-counter or fuel-gauge IC for production accuracy.
   ------------------------------------------------------------ */
struct SoCPoint { float voltage; float soc; };

static const SoCPoint socTable[] = {
    {3.00,   0},
    {3.30,  10},
    {3.50,  20},
    {3.60,  30},
    {3.70,  40},
    {3.75,  50},
    {3.80,  60},
    {3.90,  70},
    {4.00,  80},
    {4.10,  90},
    {4.20, 100}
};
static const uint8_t SOC_TABLE_SIZE = sizeof(socTable) / sizeof(SoCPoint);

BMS::BMS() {
    _refVoltage    = 3.3;
    _dividerRatio  = 1.0;
    _weakIdx       = 0;
    _strongIdx     = 0;
    _imbalance     = 0;
    _prevImbalance = 0;
    _imbalanceTrend = 0;
    _lastUpdateTime = 0;
    _packVoltage   = 0;
    _packSoC       = 0;
    _dischargeRate = 0;

    for (uint8_t i = 0; i < NUM_CELLS; i++) {
        _pins[i]        = 0;
        _cells[i].voltage = 0;
        _cells[i].soc     = 0;
    }
}

void BMS::begin(const uint8_t adcPins[NUM_CELLS], float refVoltage, float dividerRatio) {
    _refVoltage   = refVoltage;
    _dividerRatio = dividerRatio;

    for (uint8_t i = 0; i < NUM_CELLS; i++) {
        _pins[i] = adcPins[i];
        pinMode(_pins[i], INPUT);
    }

#if defined(ARDUINO_ARCH_ESP32)
    analogReadResolution(12); // 0-4095
#endif

    _lastUpdateTime = millis();
}

void BMS::setDischargeRate(float amps) {
    _dischargeRate = amps;
}

float BMS::readCellVoltage(uint8_t pin) {
    int raw = analogRead(pin);                       // 0 - 4095 (12-bit)
    float vAdc = (raw / 4095.0f) * _refVoltage;       // volts at the pin
    return vAdc * _dividerRatio;                      // scaled to real cell voltage
}

float BMS::estimateSoC(float voltage) const {
    if (voltage <= socTable[0].voltage) return socTable[0].soc;
    if (voltage >= socTable[SOC_TABLE_SIZE - 1].voltage) return socTable[SOC_TABLE_SIZE - 1].soc;

    for (uint8_t i = 0; i < SOC_TABLE_SIZE - 1; i++) {
        if (voltage >= socTable[i].voltage && voltage <= socTable[i + 1].voltage) {
            float v0 = socTable[i].voltage,   v1 = socTable[i + 1].voltage;
            float s0 = socTable[i].soc,       s1 = socTable[i + 1].soc;
            return s0 + (voltage - v0) * (s1 - s0) / (v1 - v0);
        }
    }
    return 0;
}

/* ------------------------------------------------------------
   Adaptive threshold logic (core requirement):
   Instead of one fixed mV limit, the allowed imbalance:
     - TIGHTENS near SoC extremes (<20% or >90%) -- cells are
       most sensitive to over-discharge/over-charge there.
     - RELAXES a little in the safe mid-band (40-70%).
     - WIDENS with discharge current, because higher current
       naturally increases transient voltage spread (IR drop)
       across cells with slightly different internal resistance.
   ------------------------------------------------------------ */
float BMS::computeAdaptiveThreshold() const {
    const float baseThreshold = 0.050f; // 50 mV baseline

    float socFactor = 1.0f;
    if (_packSoC < 20.0f || _packSoC > 90.0f) {
        socFactor = 0.6f;       // stricter near extremes
    } else if (_packSoC >= 40.0f && _packSoC <= 70.0f) {
        socFactor = 1.2f;       // relaxed in the safe band
    }

    float rateFactor = 1.0f + constrain(_dischargeRate / 10.0f, 0.0f, 1.0f) * 0.5f;

    return baseThreshold * socFactor * rateFactor;
}

void BMS::update() {
    unsigned long now = millis();
    float dt = (now - _lastUpdateTime) / 1000.0f;
    if (dt <= 0) dt = 0.001f;

    float sumV = 0;
    float minV = 999.0f, maxV = -999.0f;
    uint8_t minIdx = 0, maxIdx = 0;

    for (uint8_t i = 0; i < NUM_CELLS; i++) {
        float v = readCellVoltage(_pins[i]);
        _cells[i].voltage = v;
        _cells[i].soc     = estimateSoC(v);
        sumV += v;

        if (v < minV) { minV = v; minIdx = i; }
        if (v > maxV) { maxV = v; maxIdx = i; }
    }

    _weakIdx   = minIdx;
    _strongIdx = maxIdx;
    _packVoltage = sumV;

    float avgV = sumV / NUM_CELLS;
    _packSoC = estimateSoC(avgV);

    _prevImbalance = _imbalance;
    _imbalance = maxV - minV;
    _imbalanceTrend = (_imbalance - _prevImbalance) / dt; // V/s, +ve = worsening

    _lastUpdateTime = now;
}

/* ---------------------- Interface getters ---------------------- */

float BMS::getCellVoltage(uint8_t index) const {
    if (index >= NUM_CELLS) return 0;
    return _cells[index].voltage;
}

float BMS::getCellSoC(uint8_t index) const {
    if (index >= NUM_CELLS) return 0;
    return _cells[index].soc;
}

uint8_t BMS::getWeakestCellIndex()   const { return _weakIdx; }
uint8_t BMS::getStrongestCellIndex() const { return _strongIdx; }

float BMS::getWeakestCellVoltage()   const { return _cells[_weakIdx].voltage; }
float BMS::getStrongestCellVoltage() const { return _cells[_strongIdx].voltage; }

float BMS::getImbalance()      const { return _imbalance; }
float BMS::getImbalanceTrend() const { return _imbalanceTrend; }
bool  BMS::isImbalanceIncreasing() const { return _imbalanceTrend > 0.0001f; }

float BMS::getAdaptiveThreshold() const { return computeAdaptiveThreshold(); }
bool  BMS::isImbalanceCritical()  const { return _imbalance > computeAdaptiveThreshold(); }

float BMS::getPackVoltage()    const { return _packVoltage; }
float BMS::getAverageVoltage() const { return _packVoltage / NUM_CELLS; }
float BMS::getPackSoC()        const { return _packSoC; }

/* ---------------------- Serial status report ---------------------- */

static const uint8_t REPORT_WIDTH = 56;

static void printReportRule(char ch) {
    for (uint8_t i = 0; i < REPORT_WIDTH; i++) Serial.print(ch);
    Serial.println();
}

void BMS::printStatus() {
    // ---------- Header banner ----------
    printReportRule('=');
    Serial.printf(" MODULAR BMS ENGINE   |  Uptime: %6lus  |  Cells: %d\n",
                  millis() / 1000UL, NUM_CELLS);
    printReportRule('=');

    // ---------- Per-cell table ----------
    Serial.println(F(" CELL   VOLTAGE(V)   SOC(%)"));
    printReportRule('-');
    for (uint8_t i = 0; i < NUM_CELLS; i++) {
        Serial.printf("  %-4d    %7.3f      %6.1f\n",
                      i, _cells[i].voltage, _cells[i].soc);
    }
    printReportRule('-');

    // ---------- Pack summary ----------
    Serial.println(F(" PACK SUMMARY"));
    printReportRule('-');
    Serial.printf(" %-20s: %8.3f V\n", "Pack Voltage",    _packVoltage);
    Serial.printf(" %-20s: %8.3f V\n", "Average Voltage", getAverageVoltage());
    Serial.printf(" %-20s: %8.1f %%\n", "Pack SoC",        _packSoC);
    printReportRule('-');

    // ---------- Cell balance ----------
    Serial.println(F(" CELL BALANCE"));
    printReportRule('-');
    Serial.printf(" %-20s: %d  (%.3f V)\n", "Weakest Cell",   _weakIdx,   getWeakestCellVoltage());
    Serial.printf(" %-20s: %d  (%.3f V)\n", "Strongest Cell", _strongIdx, getStrongestCellVoltage());
    Serial.printf(" %-20s: %8.1f mV\n",       "Imbalance", _imbalance * 1000.0f);
    Serial.printf(" %-20s: %+8.2f mV/s (%s)\n", "Trend",
                  _imbalanceTrend * 1000.0f,
                  isImbalanceIncreasing() ? "INCREASING" : "stable/decreasing");
    Serial.printf(" %-20s: %8.1f mV\n", "Adaptive Threshold", computeAdaptiveThreshold() * 1000.0f);
    printReportRule('-');

    // ---------- Overall system status ----------
    Serial.printf(" SYSTEM STATUS: %s\n",
                  isImbalanceCritical() ? "!! CRITICAL - IMBALANCE !!" : "OK");
    printReportRule('=');
    Serial.println();
}