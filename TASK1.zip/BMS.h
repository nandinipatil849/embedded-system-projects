#ifndef BMS_H
#define BMS_H

#include <Arduino.h>

/* ============================================================
   SCALABILITY CONTROL
   Change ONLY this single constant to scale the engine from
   4 cells up to 16 cells. Every array, loop, and calculation
   in this module is sized/derived from NUM_CELLS automatically.
   ============================================================ */
#define NUM_CELLS 4

struct CellData {
    float voltage;   // Volts
    float soc;       // Estimated State of Charge (%)
};

class BMS {
public:
    BMS();

    // Must be called once in setup(). Pass an array of ADC pins,
    // sized NUM_CELLS, one pin per cell.
    void begin(const uint8_t adcPins[NUM_CELLS],
               float refVoltage   = 3.3,   // ESP32 ADC reference
               float dividerRatio = 1.0);  // set >1.0 if using an
                                            // external resistor divider
                                            // on real battery hardware

    // Call once per loop cycle (e.g. every 1000 ms)
    void update();

    // Allows an external current sensor (e.g. ACS712/INA219) to feed
    // real discharge current into the adaptive threshold calculation.
    void setDischargeRate(float amps);

    /* ---------------- Clean read-only interface ----------------
       All later modules (balancer, alarm, dashboard, logger, etc.)
       consume the BMS purely through these getters -- no need to
       re-implement cell scanning or math anywhere else.
    ---------------------------------------------------------------*/
    float   getCellVoltage(uint8_t index) const;
    float   getCellSoC(uint8_t index)     const;

    uint8_t getWeakestCellIndex()   const;
    uint8_t getStrongestCellIndex() const;
    float   getWeakestCellVoltage()   const;
    float   getStrongestCellVoltage() const;

    float   getImbalance()        const;  // Vmax - Vmin (Volts)
    float   getImbalanceTrend()   const;  // Volts/sec, +ve = worsening
    bool    isImbalanceIncreasing() const;

    float   getAdaptiveThreshold() const; // current allowed imbalance (V)
    bool    isImbalanceCritical()  const; // imbalance > adaptive threshold

    float   getPackVoltage() const;       // sum of all cells
    float   getAverageVoltage() const;    // pack voltage / NUM_CELLS
    float   getPackSoC() const;           // estimated from avg voltage

    void    printStatus();                // Serial debug dump

private:
    uint8_t  _pins[NUM_CELLS];
    CellData _cells[NUM_CELLS];

    float _refVoltage;
    float _dividerRatio;

    uint8_t _weakIdx;
    uint8_t _strongIdx;

    float _imbalance;
    float _prevImbalance;
    float _imbalanceTrend;
    unsigned long _lastUpdateTime;

    float _packVoltage;
    float _packSoC;
    float _dischargeRate;   // Amps, optional external input

    float readCellVoltage(uint8_t pin);
    float estimateSoC(float voltage) const;
    float computeAdaptiveThreshold() const;
};

#endif

