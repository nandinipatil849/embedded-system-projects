// ------------------------------------------------------------------
// 1. BLYNK CREDENTIALS  -- replace with your own from Blynk.Console
// ------------------------------------------------------------------
#define BLYNK_TEMPLATE_ID   "TMPL3P2cKjF3k"
#define BLYNK_TEMPLATE_NAME "BMS Telemetry"
#define BLYNK_AUTH_TOKEN    "ahc_hDVXxPTVcDVEN3h46rD-Gm4Gm-Dv"
#define BLYNK_PRINT Serial

#include <WiFi.h>
#include <BlynkSimpleEsp32.h>

// ------------------------------------------------------------------
// 2. PIN MAP
// ------------------------------------------------------------------
#define CELL1_PIN        34   // ADC1_CH6
#define CELL2_PIN        35   // ADC1_CH7
#define CELL3_PIN        32   // ADC1_CH4
#define CELL4_PIN        33   // ADC1_CH5

#define RELAY_PIN        25
#define FAULT_LED_PIN    26
#define WIFI_LED_PIN     27
#define HEARTBEAT_LED_PIN 14
#define BUZZER_PIN       13

#define FAULT_BTN_PIN    4    // momentary, INPUT_PULLUP, press = fault toggle
#define OUTAGE_BTN_PIN   5    // momentary, INPUT_PULLUP, press = force WiFi drop

#define NUM_CELLS 4
const uint8_t cellPins[NUM_CELLS] = { CELL1_PIN, CELL2_PIN, CELL3_PIN, CELL4_PIN };

// ------------------------------------------------------------------
// 3. WIFI / BLYNK CONFIG
// ------------------------------------------------------------------
char ssid[] = "Wokwi-GUEST";   // Wokwi's simulated open WiFi w/ real internet
char pass[] = "";
char auth[] = BLYNK_AUTH_TOKEN;

// ------------------------------------------------------------------
// 4. VIRTUAL PIN MAP (Blynk dashboard)
// ------------------------------------------------------------------
#define VPIN_CELL1        V0
#define VPIN_CELL2        V1
#define VPIN_CELL3        V2
#define VPIN_CELL4        V3
#define VPIN_MIN_V        V4
#define VPIN_MAX_V        V5
#define VPIN_MIN_IDX      V6   // weakest cell number (1-4)
#define VPIN_MAX_IDX      V7   // strongest cell number (1-4)
#define VPIN_RELAY        V8
#define VPIN_FAULT        V9
#define VPIN_RSSI         V10
#define VPIN_WIFI_QUALITY V11  // 0=down,1=poor,2=fair,3=good,4=excellent
#define VPIN_QUEUE_DEPTH  V12
#define VPIN_LOG          V13  // Terminal widget: LIVE/QUEUED event log
#define VPIN_RELAY_OVERRIDE V16 // app switch: manual relay force-open
#define VPIN_DROPPED      V17

// ------------------------------------------------------------------
// 5. THRESHOLDS / TIMING
// ------------------------------------------------------------------
const float VOLTAGE_DELTA_THRESHOLD = 0.02f;   // volts, triggers an event
const float FAULT_LOW_VOLTAGE   = 3.05f;
const float FAULT_HIGH_VOLTAGE  = 4.20f;
const unsigned long HEARTBEAT_INTERVAL = 30000UL;
const unsigned long SAMPLE_INTERVAL    = 500UL;
const unsigned long DEBOUNCE_MS        = 250UL;

// ------------------------------------------------------------------
// 6. OFFLINE QUEUE (fixed-size ring buffer)
// ------------------------------------------------------------------
#define QUEUE_SIZE 20

enum EventType { EVT_PERIODIC, EVT_THRESHOLD, EVT_FAULT, EVT_RELAY, EVT_SYNC };

struct TelemetryEvent {
  unsigned long timestamp;
  float cellV[NUM_CELLS];
  float minV, maxV;
  uint8_t minIdx, maxIdx;
  bool relayState;
  bool faultState;
  int rssi;
  EventType type;
};

TelemetryEvent queueBuf[QUEUE_SIZE];
int qHead = 0, qTail = 0, qCount = 0;
unsigned long droppedEvents = 0;

bool queuePush(const TelemetryEvent &e) {
  if (qCount == QUEUE_SIZE) {          // full -> drop oldest, keep queue moving
    qHead = (qHead + 1) % QUEUE_SIZE;
    qCount--;
    droppedEvents++;
  }
  queueBuf[qTail] = e;
  qTail = (qTail + 1) % QUEUE_SIZE;
  qCount++;
  return true;
}

bool queuePop(TelemetryEvent &e) {
  if (qCount == 0) return false;
  e = queueBuf[qHead];
  qHead = (qHead + 1) % QUEUE_SIZE;
  qCount--;
  return true;
}

// ------------------------------------------------------------------
// 7. WIFI NON-BLOCKING STATE MACHINE
// ------------------------------------------------------------------
enum WifiState { WS_DISCONNECTED, WS_CONNECTING, WS_CONNECTED, WS_BACKOFF };
WifiState wifiState = WS_DISCONNECTED;
unsigned long wifiTimer = 0;
unsigned long backoffDelay = 2000UL;
const unsigned long CONNECT_TIMEOUT = 15000UL;
const unsigned long BACKOFF_MAX     = 30000UL;
bool wifiUp = false;          // debounced "link usable" flag

void handleWifiStateMachine() {
  switch (wifiState) {

    case WS_DISCONNECTED:
      Serial.println("[WiFi] Starting connection attempt...");
      WiFi.mode(WIFI_STA);
      WiFi.begin(ssid, pass);
      wifiTimer = millis();
      wifiState = WS_CONNECTING;
      break;

    case WS_CONNECTING:
      if (WiFi.status() == WL_CONNECTED) {
        Serial.println("[WiFi] Connected.");
        wifiUp = true;
        backoffDelay = 2000UL;           // reset backoff on success
        wifiState = WS_CONNECTED;
      } else if (millis() - wifiTimer > CONNECT_TIMEOUT) {
        Serial.println("[WiFi] Connect timeout -> backoff.");
        wifiState = WS_BACKOFF;
        wifiTimer = millis();
      }
      break;

    case WS_CONNECTED:
      if (WiFi.status() != WL_CONNECTED) {
        Serial.println("[WiFi] Link lost.");
        wifiUp = false;
        wifiState = WS_DISCONNECTED;
      }
      break;

    case WS_BACKOFF:
      if (millis() - wifiTimer > backoffDelay) {
        backoffDelay = min(backoffDelay * 2, BACKOFF_MAX);   // exponential backoff
        wifiState = WS_DISCONNECTED;
      }
      break;
  }
}

// ------------------------------------------------------------------
// 8. BLYNK NON-BLOCKING CONNECT
// ------------------------------------------------------------------
unsigned long lastBlynkAttempt = 0;
const unsigned long BLYNK_RETRY_INTERVAL = 5000UL;

void handleBlynkConnection() {
  if (!wifiUp) return;
  if (Blynk.connected()) { Blynk.run(); return; }
  if (millis() - lastBlynkAttempt > BLYNK_RETRY_INTERVAL) {
    lastBlynkAttempt = millis();
    Serial.println("[Blynk] Attempting non-blocking connect...");
    Blynk.connect(5000);           // 0ms timeout -> returns immediately, no block
  }
}

// ------------------------------------------------------------------
// 9. GLOBAL SYSTEM STATE
// ------------------------------------------------------------------
float lastSentV[NUM_CELLS]  = {0,0,0,0};
bool  relayState             = true;    // true = closed / connected
bool  faultState              = false;
bool  manualFault              = false;
bool  relayOverrideOpen         = false; // operator forces relay open from app
unsigned long lastSampleTime      = 0;
unsigned long lastHeartbeat        = 0;
unsigned long lastFaultBtnPress     = 0;
unsigned long lastOutageBtnPress     = 0;
bool wasConnectedForFlush              = false; // edge-detect for queue flush
unsigned long lastFlushSend               = 0;
const unsigned long FLUSH_PACING_MS        = 150UL; // pacing while draining queue

// ------------------------------------------------------------------
// 10. HELPERS
// ------------------------------------------------------------------
float readCellVoltage(uint8_t pin) {
  uint32_t mv = analogReadMilliVolts(pin);       // calibrated ADC read (0-3300mV)
  return 3.0f + (mv / 3300.0f) * 1.2f;            // map to 3.0V - 4.2V cell range
}

int wifiQualityLevel(int rssi) {
  if (!wifiUp) return 0;
  if (rssi > -60) return 4;      // excellent
  if (rssi > -70) return 3;      // good
  if (rssi > -80) return 2;      // fair
  return 1;                       // poor
}

bool linkFullyUp() {
  return wifiUp && Blynk.connected();
}

// ------------------------------------------------------------------
// 11. BUILD + DISPATCH A TELEMETRY EVENT
// ------------------------------------------------------------------
TelemetryEvent buildEvent(float v[NUM_CELLS], EventType type) {
  TelemetryEvent e;
  e.timestamp = millis();
  float mn = v[0], mx = v[0];
  uint8_t mnI = 0, mxI = 0;
  for (uint8_t i = 0; i < NUM_CELLS; i++) {
    e.cellV[i] = v[i];
    if (v[i] < mn) { mn = v[i]; mnI = i; }
    if (v[i] > mx) { mx = v[i]; mxI = i; }
  }
  e.minV = mn; e.maxV = mx; e.minIdx = mnI; e.maxIdx = mxI;
  e.relayState = relayState;
  e.faultState = faultState;
  e.rssi = wifiUp ? WiFi.RSSI() : -100;
  e.type = type;
  return e;
}

void pushToDashboard(const TelemetryEvent &e, bool isLive) {
  Blynk.virtualWrite(VPIN_CELL1, e.cellV[0]);
  Blynk.virtualWrite(VPIN_CELL2, e.cellV[1]);
  Blynk.virtualWrite(VPIN_CELL3, e.cellV[2]);
  Blynk.virtualWrite(VPIN_CELL4, e.cellV[3]);
  Blynk.virtualWrite(VPIN_MIN_V, e.minV);
  Blynk.virtualWrite(VPIN_MAX_V, e.maxV);
  Blynk.virtualWrite(VPIN_MIN_IDX, e.minIdx + 1);
  Blynk.virtualWrite(VPIN_MAX_IDX, e.maxIdx + 1);
  Blynk.virtualWrite(VPIN_RELAY, e.relayState ? 1 : 0);
  Blynk.virtualWrite(VPIN_FAULT, e.faultState ? 1 : 0);
  Blynk.virtualWrite(VPIN_RSSI, e.rssi);
  Blynk.virtualWrite(VPIN_WIFI_QUALITY, wifiQualityLevel(e.rssi));
  Blynk.virtualWrite(VPIN_QUEUE_DEPTH, qCount);
  Blynk.virtualWrite(VPIN_DROPPED, droppedEvents);

  String tag = isLive ? "LIVE" : "QUEUED";
  String typeStr;
  switch (e.type) {
    case EVT_THRESHOLD: typeStr = "THRESHOLD"; break;
    case EVT_FAULT:      typeStr = "FAULT";     break;
    case EVT_RELAY:      typeStr = "RELAY";     break;
    case EVT_SYNC:        typeStr = "SYNC";      break;
    default:               typeStr = "HEARTBEAT";
  }
  Blynk.virtualWrite(VPIN_LOG,
    "[" + tag + "] t=" + String(e.timestamp / 1000) + "s " + typeStr +
    " minV=" + String(e.minV, 2) + " maxV=" + String(e.maxV, 2) +
    " relay=" + String(e.relayState ? "CLOSED" : "OPEN") +
    " fault=" + String(e.faultState ? "YES" : "NO"));
}

// Decide where an event goes: straight to Blynk, or into the offline queue
void dispatchEvent(const TelemetryEvent &e) {
  if (linkFullyUp()) {
    pushToDashboard(e, true);
  } else {
    queuePush(e);
    Serial.printf("[Queue] Buffered event (depth=%d, dropped=%lu)\n", qCount, droppedEvents);
  }
}

// Drain the queue in FIFO order once connectivity is restored, paced
// so we don't flood Blynk's rate limiter.
void drainQueueIfConnected() {
  if (!linkFullyUp()) return;
  if (qCount == 0) return;
  if (millis() - lastFlushSend < FLUSH_PACING_MS) return;

  TelemetryEvent e;
  if (queuePop(e)) {
    pushToDashboard(e, false);          // isLive = false -> tagged QUEUED
    lastFlushSend = millis();
  }
  Blynk.virtualWrite(VPIN_QUEUE_DEPTH, qCount);
}

// ------------------------------------------------------------------
// 12. BLYNK APP CONTROLS
// ------------------------------------------------------------------
BLYNK_WRITE(VPIN_RELAY_OVERRIDE) {
  relayOverrideOpen = param.asInt();
  Serial.printf("[App] Relay override = %s\n", relayOverrideOpen ? "OPEN" : "AUTO");
}

BLYNK_CONNECTED() {
  Serial.println("[Blynk] Handshake complete, syncing widgets.");
  Blynk.syncVirtual(VPIN_RELAY_OVERRIDE);
}

// ------------------------------------------------------------------
// 13. SETUP
// ------------------------------------------------------------------
void setup() {
  Serial.begin(115200);
  delay(200);
  Serial.println("\n=== Event-Driven Telemetry BMS Booting ===");

  pinMode(RELAY_PIN, OUTPUT);
  pinMode(FAULT_LED_PIN, OUTPUT);
  pinMode(WIFI_LED_PIN, OUTPUT);
  pinMode(HEARTBEAT_LED_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(FAULT_BTN_PIN, INPUT_PULLUP);
  pinMode(OUTAGE_BTN_PIN, INPUT_PULLUP);

  digitalWrite(RELAY_PIN, HIGH);   // closed / battery connected
  digitalWrite(BUZZER_PIN, LOW);

  analogReadResolution(12);

  Blynk.config(auth);              // configure only; connection handled non-blocking in loop

  wifiState = WS_DISCONNECTED;     // kick off state machine
}

// ------------------------------------------------------------------
// 14. MAIN LOOP  (fully non-blocking)
// ------------------------------------------------------------------
void loop() {
  handleWifiStateMachine();
  handleBlynkConnection();

  digitalWrite(WIFI_LED_PIN, wifiUp ? HIGH : LOW);
  digitalWrite(HEARTBEAT_LED_PIN, (millis() / 500) % 2);   // simple 1Hz blink = "alive"

  // ---- Buttons (debounced) ----
  if (digitalRead(FAULT_BTN_PIN) == LOW && millis() - lastFaultBtnPress > DEBOUNCE_MS) {
    lastFaultBtnPress = millis();
    manualFault = !manualFault;
    Serial.printf("[Button] Manual fault injection: %s\n", manualFault ? "ON" : "OFF");
  }

  if (digitalRead(OUTAGE_BTN_PIN) == LOW && millis() - lastOutageBtnPress > DEBOUNCE_MS) {
    lastOutageBtnPress = millis();
    Serial.println("[Button] Forcing simulated network outage (WiFi.disconnect).");
    WiFi.disconnect(true);
    wifiUp = false;
    wifiState = WS_DISCONNECTED;   // state machine will retry automatically
  }

  // ---- Detect reconnection edge -> flush queue ----
  bool nowConnected = linkFullyUp();
  if (nowConnected && !wasConnectedForFlush) {
    Serial.println("[Sync] Link restored - draining offline queue.");
    TelemetryEvent syncEvt = buildEvent(lastSentV, EVT_SYNC);
    pushToDashboard(syncEvt, true);
  }
  wasConnectedForFlush = nowConnected;
  drainQueueIfConnected();

  // ---- Periodic sampling ----
  if (millis() - lastSampleTime >= SAMPLE_INTERVAL) {
    lastSampleTime = millis();

    float v[NUM_CELLS];
    for (uint8_t i = 0; i < NUM_CELLS; i++) v[i] = readCellVoltage(cellPins[i]);

    float mn = v[0], mx = v[0];
    for (uint8_t i = 1; i < NUM_CELLS; i++) {
      if (v[i] < mn) mn = v[i];
      if (v[i] > mx) mx = v[i];
    }

    bool autoFault = (mn < FAULT_LOW_VOLTAGE) || (mx > FAULT_HIGH_VOLTAGE);
    bool newFault = autoFault || manualFault;
    bool newRelay = !(newFault || relayOverrideOpen);   // open relay on fault or override

    bool faultChanged = (newFault != faultState);
    bool relayChanged = (newRelay != relayState);

    bool thresholdCrossed = false;
    for (uint8_t i = 0; i < NUM_CELLS; i++) {
      if (fabs(v[i] - lastSentV[i]) >= VOLTAGE_DELTA_THRESHOLD) { thresholdCrossed = true; break; }
    }

    faultState = newFault;
    relayState = newRelay;
    digitalWrite(RELAY_PIN, relayState ? HIGH : LOW);
    digitalWrite(FAULT_LED_PIN, faultState ? HIGH : LOW);
    digitalWrite(BUZZER_PIN, faultState ? HIGH : LOW);

    // ---- Event-driven decision: only transmit on a meaningful change ----
    EventType evtType = EVT_PERIODIC;
    bool shouldSend = false;

    if (faultChanged)      { evtType = EVT_FAULT;     shouldSend = true; }
    else if (relayChanged) { evtType = EVT_RELAY;     shouldSend = true; }
    else if (thresholdCrossed) { evtType = EVT_THRESHOLD; shouldSend = true; }
    else if (millis() - lastHeartbeat >= HEARTBEAT_INTERVAL) {
      evtType = EVT_PERIODIC;
      shouldSend = true;
    }

    if (shouldSend) {
      lastHeartbeat = millis();
      for (uint8_t i = 0; i < NUM_CELLS; i++) lastSentV[i] = v[i];
      TelemetryEvent e = buildEvent(v, evtType);
      dispatchEvent(e);
    }
  }
}